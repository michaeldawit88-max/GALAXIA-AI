const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export type AIMode = "text" | "phone" | "video" | "facetoface";

export interface AIRequest {
  mode: AIMode;
  userText: string;
  conversationHistory?: Array<{ role: "user" | "assistant"; content: string }>;
}

export async function askGalaxia(req: AIRequest): Promise<string> {
  const response = await fetch(`${SUPABASE_URL}/functions/v1/galaxia-ai`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
      Apikey: SUPABASE_ANON_KEY,
    },
    body: JSON.stringify(req),
  });

  const data = await response.json();

  if (!response.ok || data.error) {
    throw new Error(data.error ?? `Request failed (${response.status})`);
  }

  if (typeof data.suggestion !== "string" || !data.suggestion) {
    throw new Error("No suggestion returned from AI.");
  }

  return data.suggestion;
}
