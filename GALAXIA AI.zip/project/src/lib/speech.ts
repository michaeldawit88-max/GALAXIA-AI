import { useRef, useState, useCallback } from "react";

// ─── LEVENSHTEIN DISTANCE (fuzzy typo correction) ─────────────────────────────
function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i-1] === b[j-1]
        ? dp[i-1][j-1]
        : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
    }
  }
  return dp[m][n];
}

// Returns similarity 0-1 (1 = identical). Words within 80% similarity match.
export function fuzzyMatch(input: string, target: string): boolean {
  const a = input.toLowerCase().trim();
  const b = target.toLowerCase().trim();
  if (a === b) return true;
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return true;
  const similarity = 1 - levenshtein(a, b) / maxLen;
  return similarity >= 0.8;
}

// ─── AUDIO CUE GENERATOR ──────────────────────────────────────────────────────
// "Boop" = mic live (high pitch), "Bzzz" = glitch/error (low buzz)
function playAudioCue(type: "boop" | "bzzz") {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === "boop") {
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.18);
    } else {
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(180, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.28);
    }

    osc.onended = () => ctx.close();
  } catch {
    // Audio not available — silent fallback
  }
}

// ─── HARDCODED FALLBACK RESPONSE ─────────────────────────────────────────────
// Used when the AI call fails or returns nothing — never freeze/blank.
export const FALLBACK_RESPONSE =
  "Context evolving. Maintain a neutral tone, observe the speaker, and withhold immediate commitment until more data is parsed.";

interface SpeechOptions {
  continuous?: boolean;
  onTranscript: (text: string, isFinal: boolean) => void;
  onError?: (error: string) => void;
  autoRestart?: boolean; // default true — kicks mic back on within 50ms of any shutdown
}

export function useSpeechRecognition(options: SpeechOptions) {
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const [isListening, setIsListening] = useState(false);
  const shouldRestartRef = useRef(false);
  const restartTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [supported] = useState(() => {
    return "SpeechRecognition" in window || "webkitSpeechRecognition" in window;
  });

  const autoRestart = options.autoRestart !== false;

  const createRecognition = useCallback((): SpeechRecognition | null => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return null;

    const recognition = new SR() as SpeechRecognition;
    recognition.continuous = options.continuous ?? true;
    recognition.interimResults = true;
    recognition.lang = "en-US";
    recognition.maxAlternatives = 3; // extra alternatives for fuzzy fallback

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interim = "";
      let finalText = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        // Pick best alternative (highest confidence) with fuzzy awareness
        const best = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalText += best;
        } else {
          interim += best;
        }
      }
      // Async guard: schedule on microtask to avoid blocking render
      if (finalText) Promise.resolve().then(() => options.onTranscript(finalText, true));
      if (interim)   Promise.resolve().then(() => options.onTranscript(interim, false));
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      if (event.error === "not-allowed" || event.error === "service-not-allowed") {
        shouldRestartRef.current = false;
        options.onError?.("Microphone access denied. Please allow mic permission.");
        setIsListening(false);
        playAudioCue("bzzz");
        return;
      }
      // no-speech & aborted are expected during normal use — don't surface as errors
      if (event.error !== "aborted" && event.error !== "no-speech") {
        options.onError?.(`Speech error: ${event.error}`);
        playAudioCue("bzzz");
      }
    };

    recognition.onend = () => {
      setIsListening(false);
      // Auto-restart within 50ms — user feels continuous listening
      if (shouldRestartRef.current && autoRestart) {
        if (restartTimerRef.current) clearTimeout(restartTimerRef.current);
        restartTimerRef.current = setTimeout(() => {
          if (!shouldRestartRef.current) return;
          try {
            const newRec = createRecognition();
            if (!newRec) return;
            recognitionRef.current = newRec;
            newRec.start();
            setIsListening(true);
            // No boop on silent restart — only on explicit user-initiated start
          } catch {
            // If restart fails, just stay stopped
          }
        }, 50);
      }
    };

    return recognition;
  }, [options, autoRestart]);

  const start = useCallback(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      options.onError?.("Speech recognition not supported. Please use Chrome.");
      return;
    }

    shouldRestartRef.current = true;
    const recognition = createRecognition();
    if (!recognition) return;

    recognitionRef.current = recognition;
    try {
      recognition.start();
      setIsListening(true);
      playAudioCue("boop"); // "Mic is live" confirmation
    } catch {
      setIsListening(false);
      playAudioCue("bzzz");
    }
  }, [createRecognition, options]);

  const stop = useCallback(() => {
    shouldRestartRef.current = false;
    if (restartTimerRef.current) clearTimeout(restartTimerRef.current);
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    setIsListening(false);
  }, []);

  return { isListening, supported, start, stop };
}

export function speakText(text: string, rate = 1.1, pitch = 1) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = rate;
  utterance.pitch = pitch;
  utterance.volume = 1;
  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(v =>
    v.name.includes("Google") || v.name.includes("Natural") || v.name.includes("Premium")
  ) || voices.find(v => v.lang.startsWith("en")) || voices[0];
  if (preferred) utterance.voice = preferred;
  window.speechSynthesis.speak(utterance);
}
