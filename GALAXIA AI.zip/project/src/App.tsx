import { useState, useCallback } from "react"
import { InstallBanner, useInstallPrompt } from "@/components/InstallBanner"
import { Box, Flex, Text, Grid, VStack, HStack, Button, Icon } from "@chakra-ui/react"
import { LuMessageSquare, LuPhone, LuVideo, LuBluetooth, LuFileText, LuShield, LuBell, LuDownload } from "react-icons/lu"
import TermsModal from "@/components/TermsModal"
import FeatureCard from "@/components/FeatureCard"
import LegalModal from "@/components/LegalModal"
import NotificationReader from "@/components/NotificationReader"
import GlaxiaLogo from "@/components/GlaxiaLogo"
import SpaceBackground from "@/components/SpaceBackground"
import TextAssistant from "@/components/assistants/TextAssistant"
import PhoneAssistant from "@/components/assistants/PhoneAssistant"
import VideoAssistant from "@/components/assistants/VideoAssistant"
import FaceToFaceAssistant from "@/components/assistants/FaceToFaceAssistant"

export type AssistantId = "text" | "phone" | "video" | "facetoface"

export interface AssistantConfig {
  id: AssistantId
  title: string
  description: string
  iconElement: React.ReactNode
  color: string
  glowAnim: string
  accentHex: string
  borderHex: string
  bgHex: string
}

export const ASSISTANTS: AssistantConfig[] = [
  {
    id: "text",
    title: "Text Message Assistant",
    description: "Paste any conversation — GALAXIA reads it, matches your style, and crafts the perfect tactical psychological reply.",
    iconElement: <LuMessageSquare />,
    color: "blue",
    glowAnim: "titleGlowBlue",
    accentHex: "#60a5fa",
    borderHex: "rgba(59,130,246,0.6)",
    bgHex: "rgba(59,130,246,0.07)",
  },
  {
    id: "phone",
    title: "Phone Call Support",
    description: "Listens live via microphone during phone calls. In under a second, delivers tactical suggestions directly on your screen.",
    iconElement: <LuPhone />,
    color: "green",
    glowAnim: "titleGlowGreen",
    accentHex: "#4ade80",
    borderHex: "rgba(74,222,128,0.6)",
    bgHex: "rgba(74,222,128,0.07)",
  },
  {
    id: "video",
    title: "Video Call Assistant",
    description: "Listens in real-time during video calls. Transparent overlay delivers accurate suggestions mid-conversation.",
    iconElement: <LuVideo />,
    color: "purple",
    glowAnim: "titleGlowPurple",
    accentHex: "#c084fc",
    borderHex: "rgba(192,132,252,0.6)",
    bgHex: "rgba(192,132,252,0.07)",
  },
  {
    id: "facetoface",
    title: "Face-to-Face Conversation Assistant",
    description: "Listens to real-world conversations and whispers the perfect response directly to your Bluetooth earpiece in under a second.",
    iconElement: <LuBluetooth />,
    color: "gold",
    glowAnim: "titleGlowGold",
    accentHex: "#fbbf24",
    borderHex: "rgba(251,191,36,0.6)",
    bgHex: "rgba(251,191,36,0.07)",
  },
]

export default function App() {
  const [activeAssistants, setActiveAssistants] = useState<Set<AssistantId>>(new Set())
  const [pendingActivation, setPendingActivation] = useState<AssistantId | null>(null)
  const [openAssistant, setOpenAssistant] = useState<AssistantId | null>(null)
  const [deactivateTarget, setDeactivateTarget] = useState<AssistantId | null>(null)
  const [legalPage, setLegalPage] = useState<"terms" | "privacy" | null>(null)
  const { prompt: installPrompt, installed, install } = useInstallPrompt()
  const [notifOpen, setNotifOpen] = useState(false)

  const handleCardClick = useCallback((id: AssistantId) => {
    if (activeAssistants.has(id)) {
      setDeactivateTarget(id)
    } else {
      setPendingActivation(id)
    }
  }, [activeAssistants])

  const handleAgree = useCallback((id: AssistantId) => {
    setActiveAssistants(prev => new Set([...prev, id]))
    setPendingActivation(null)
    setOpenAssistant(id)
  }, [])

  const handleDecline = useCallback(() => setPendingActivation(null), [])

  const handleDeactivate = useCallback((id: AssistantId) => {
    setActiveAssistants(prev => {
      const next = new Set(prev)
      next.delete(id)
      return next
    })
    setDeactivateTarget(null)
    if (openAssistant === id) setOpenAssistant(null)
  }, [openAssistant])

  const handleCancelDeactivate = useCallback(() => setDeactivateTarget(null), [])
  const handleCloseAssistant = useCallback(() => setOpenAssistant(null), [])

  // Re-open assistant when clicking active card dot area
  const handleActiveCardClick = useCallback((id: AssistantId) => {
    setOpenAssistant(id)
  }, [])

  return (
    <Box minH="100vh" position="relative">
      <SpaceBackground />

      {/* Blue status indicators for active assistants */}
      {Array.from(activeAssistants).map((id, idx) => (
        <Box
          key={id}
          as="button"
          onClick={() => setOpenAssistant(id)}
          position="fixed"
          top="14px"
          right={`${14 + idx * 22}px`}
          w="10px"
          h="10px"
          borderRadius="full"
          zIndex="banner"
          cursor="pointer"
          title={ASSISTANTS.find(a => a.id === id)?.title}
          css={{
            background: ASSISTANTS.find(a => a.id === id)?.accentHex,
            boxShadow: `0 0 10px 3px ${ASSISTANTS.find(a => a.id === id)?.accentHex}cc, 0 0 22px 8px ${ASSISTANTS.find(a => a.id === id)?.accentHex}50`,
            animation: "pulse 1.5s ease-in-out infinite",
          }}
        />
      ))}

      {/* Content */}
      <Box
        position="relative"
        zIndex={1}
        px={{ base: "4", md: "8", lg: "16" }}
        py={{ base: "8", md: "12" }}
      >
        <VStack align="flex-start" gap="2" mb={{ base: "10", md: "16" }}>
          <GlaxiaLogo />
          <NeonSubtitle />

          {/* Install CTA — shown only when PWA installable and not yet installed */}
          {!installed && (installPrompt || /iphone|ipad|ipod|android/i.test(navigator.userAgent)) && (
            <Box
              as="button"
              onClick={() => {
                if (installPrompt) install()
                else {
                  // iOS — show instructions
                  const event = new CustomEvent("galaxia:showInstall")
                  window.dispatchEvent(event)
                }
              }}
              mt="2"
              px="5" py="2.5"
              display="flex" alignItems="center" gap="2"
              cursor="pointer" transition="all 0.2s"
              css={{
                borderRadius: "full",
                background: "rgba(99,102,241,0.12)",
                border: "1px solid rgba(99,102,241,0.45)",
                color: "#818cf8",
                fontSize: "13px", fontWeight: "700", letterSpacing: "0.06em",
                boxShadow: "0 0 20px rgba(99,102,241,0.25)",
                "&:hover": { background: "rgba(99,102,241,0.22)", boxShadow: "0 0 30px rgba(99,102,241,0.5)" },
              }}
            >
              <Icon boxSize="4"><LuDownload /></Icon>
              INSTALL APP — FREE
            </Box>
          )}
        </VStack>

        <Grid
          templateColumns={{ base: "1fr", md: "1fr 1fr" }}
          gap={{ base: "5", md: "6", lg: "8" }}
          maxW="1100px"
          mx="auto"
        >
          {ASSISTANTS.map(assistant => (
            <FeatureCard
              key={assistant.id}
              assistant={assistant}
              isActive={activeAssistants.has(assistant.id)}
              onClick={() => handleCardClick(assistant.id)}
            />
          ))}

          {/* Notification Intelligence card */}
          <Box
            as="button"
            onClick={() => setNotifOpen(true)}
            textAlign="left" w="full" position="relative"
            p={{ base: "5", md: "7" }}
            cursor="pointer" transition="all 0.35s ease"
            css={{
              borderRadius: "1.25rem",
              border: "1px solid rgba(245,158,11,0.3)",
              background: "rgba(245,158,11,0.05)",
              boxShadow: "0 0 18px rgba(245,158,11,0.15), 0 4px 30px rgba(0,0,0,0.4)",
              backdropFilter: "blur(14px)",
              "&:hover": {
                border: "1px solid rgba(245,158,11,0.6)",
                background: "rgba(245,158,11,0.09)",
                boxShadow: "0 0 40px rgba(245,158,11,0.4), 0 0 100px rgba(245,158,11,0.15)",
                transform: "translateY(-3px)",
              },
            }}
          >
            <HStack gap="4">
              <Box w="12" h="12" borderRadius="xl"
                display="flex" alignItems="center" justifyContent="center"
                css={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)" }}>
                <Icon boxSize="5" css={{ color: "#f59e0b" }}><LuBell /></Icon>
              </Box>
              <VStack align="flex-start" gap="1">
                <Text fontWeight="bold" fontSize="sm" css={{ color: "#fbbf24", textShadow: "0 0 10px #f59e0b80" }}>
                  Notification Intelligence
                </Text>
                <Text fontSize="sm" color="gray.400" lineHeight="tall">
                  Paste any message from iMessage, WhatsApp, Instagram, or email — GALAXIA crafts the perfect reply instantly.
                </Text>
                <HStack gap="2" mt="1">
                  <Box w="6px" h="6px" borderRadius="full" css={{ background: "#f59e0b" }} />
                  <Text fontSize="xs" color="gray.500" letterSpacing="wide" fontWeight="medium" textTransform="uppercase">
                    TAP TO OPEN
                  </Text>
                </HStack>
              </VStack>
            </HStack>
          </Box>
        </Grid>

        <Box textAlign="center" mt="16" pb="8">
          <Text fontSize="xs" color="gray.600" letterSpacing="widest" textTransform="uppercase" mb="3" opacity={0.4}>
            GALAXIA AI · Elite Negotiation Intelligence · All sessions private
          </Text>
          <HStack gap="4" justify="center">
            <Box
              as="button" onClick={() => setLegalPage("terms")}
              display="flex" alignItems="center" gap="1.5" cursor="pointer"
              css={{
                color: "#4b5563",
                fontSize: "11px", fontWeight: "600", letterSpacing: "0.06em", textTransform: "uppercase",
                "&:hover": { color: "#60a5fa" }, transition: "color 0.2s",
              }}
            >
              <Icon boxSize="3"><LuFileText /></Icon>
              Terms of Service
            </Box>
            <Text fontSize="xs" color="gray.700">·</Text>
            <Box
              as="button" onClick={() => setLegalPage("privacy")}
              display="flex" alignItems="center" gap="1.5" cursor="pointer"
              css={{
                color: "#4b5563",
                fontSize: "11px", fontWeight: "600", letterSpacing: "0.06em", textTransform: "uppercase",
                "&:hover": { color: "#34d399" }, transition: "color 0.2s",
              }}
            >
              <Icon boxSize="3"><LuShield /></Icon>
              Privacy Policy
            </Box>
          </HStack>
        </Box>
      </Box>

      {/* Terms Modal */}
      {pendingActivation && (
        <TermsModal
          assistantId={pendingActivation}
          onAgree={() => handleAgree(pendingActivation)}
          onDecline={handleDecline}
        />
      )}

      {/* Deactivate Dialog */}
      {deactivateTarget && (
        <DeactivateDialog
          assistantId={deactivateTarget}
          onConfirm={() => handleDeactivate(deactivateTarget)}
          onCancel={handleCancelDeactivate}
          onOpen={() => { setDeactivateTarget(null); setOpenAssistant(deactivateTarget) }}
        />
      )}

      {/* Live AI Assistant Panels */}
      {openAssistant === "text" && <TextAssistant onClose={handleCloseAssistant} />}
      {openAssistant === "phone" && <PhoneAssistant onClose={handleCloseAssistant} />}
      {openAssistant === "video" && <VideoAssistant onClose={handleCloseAssistant} />}
      {openAssistant === "facetoface" && <FaceToFaceAssistant onClose={handleCloseAssistant} />}
      {notifOpen && <NotificationReader onClose={() => setNotifOpen(false)} />}
      <InstallBanner prompt={installPrompt} installed={installed} install={install} />

      {legalPage && (
        <LegalModal page={legalPage} onClose={() => setLegalPage(null)} />
      )}
    </Box>
  )
}

function NeonSubtitle() {
  const words = [
    { text: "GALAXIA", hex: "#60a5fa", delay: "0s" },
    { text: "AI", hex: "#4ade80", delay: "0.4s" },
    { text: "POWERED", hex: "#c084fc", delay: "0.8s" },
    { text: "CONVERSATION", hex: "#60a5fa", delay: "1.2s" },
    { text: "ASSISTANT", hex: "#fbbf24", delay: "1.6s" },
  ]
  return (
    <Flex wrap="wrap" gap="2" align="center" mt="1">
      {words.map((w) => (
        <Text
          key={w.text}
          fontSize={{ base: "sm", md: "md", lg: "lg" }}
          fontWeight="bold"
          letterSpacing="wider"
          css={{
            color: w.hex,
            textShadow: `0 0 6px ${w.hex}, 0 0 16px ${w.hex}, 0 0 32px ${w.hex}cc, 0 0 60px ${w.hex}66`,
            animation: `neonBreath 2.5s ease-in-out ${w.delay} infinite alternate`,
          }}
        >
          {w.text}
        </Text>
      ))}
    </Flex>
  )
}

function DeactivateDialog({
  assistantId,
  onConfirm,
  onCancel,
  onOpen,
}: {
  assistantId: AssistantId
  onConfirm: () => void
  onCancel: () => void
  onOpen: () => void
}) {
  const assistant = ASSISTANTS.find(a => a.id === assistantId)!
  return (
    <Box
      position="fixed" inset={0} zIndex="overlay"
      display="flex" alignItems="center" justifyContent="center"
      css={{ backdropFilter: "blur(10px)", background: "rgba(0,0,0,0.75)" }}
    >
      <Box
        p="7" maxW="400px" w="90%" textAlign="center"
        css={{
          background: "rgba(4,3,20,0.97)",
          border: `1px solid ${assistant.borderHex}`,
          borderRadius: "1.5rem",
          boxShadow: `0 0 40px ${assistant.accentHex}40, 0 0 80px ${assistant.accentHex}20`,
        }}
      >
        <Box
          w="12" h="12" borderRadius="full" mx="auto" mb="4"
          display="flex" alignItems="center" justifyContent="center"
          css={{
            background: `${assistant.accentHex}18`,
            border: `1px solid ${assistant.borderHex}`,
            boxShadow: `0 0 20px ${assistant.accentHex}60`,
          }}
        >
          <Icon css={{ color: assistant.accentHex }} boxSize="5">{assistant.iconElement}</Icon>
        </Box>
        <Text color="white" fontWeight="bold" fontSize="md" mb="1"
          css={{ textShadow: `0 0 12px ${assistant.accentHex}, 0 0 30px ${assistant.accentHex}80` }}>
          {assistant.title}
        </Text>
        <Text color="gray.400" fontSize="sm" mb="5">This assistant is currently active. What would you like to do?</Text>
        <VStack gap="2">
          <Box
            as="button" onClick={onOpen} w="full" py="2.5" borderRadius="xl" cursor="pointer"
            display="flex" alignItems="center" justifyContent="center"
            css={{
              background: `${assistant.accentHex}18`,
              border: `1px solid ${assistant.accentHex}50`,
              color: assistant.accentHex,
              fontWeight: "700", fontSize: "0.8rem", letterSpacing: "0.08em",
              boxShadow: `0 0 12px ${assistant.accentHex}30`,
              "&:hover": { background: `${assistant.accentHex}28` },
            }}>
            OPEN ASSISTANT
          </Box>
          <HStack gap="2" w="full">
            <Button flex={1} variant="outline" borderColor="gray.700" color="gray.400"
              _hover={{ bg: "gray.900" }} onClick={onCancel} size="sm">
              Cancel
            </Button>
            <Button flex={1} size="sm" onClick={onConfirm}
              css={{
                background: "rgba(127,0,0,0.4)", color: "#fca5a5",
                border: "1px solid rgba(239,68,68,0.5)",
                "&:hover": { background: "rgba(127,0,0,0.6)" },
              }}>
              Deactivate
            </Button>
          </HStack>
        </VStack>
      </Box>
    </Box>
  )
}
