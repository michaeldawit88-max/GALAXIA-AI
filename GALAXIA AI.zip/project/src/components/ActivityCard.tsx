import { useState, useEffect } from "react"
import { Box, VStack, HStack, Text, Heading, Icon, Badge } from "@chakra-ui/react"
import {
  LuActivity, LuMessageSquare, LuClock, LuZap, LuCrown, LuCheck, LuTrendingUp,
} from "react-icons/lu"
import { fetchTodayUsage } from "@/lib/ai"

const DAILY_MESSAGE_CAP = 10
const DAILY_MINUTE_CAP = 10

export default function ActivityCard() {
  const [messageCount, setMessageCount] = useState(0)
  const [minutesUsed, setMinutesUsed] = useState(0)
  const [timeSavedSeconds, setTimeSavedSeconds] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchTodayUsage()
      .then(({ messageCount, minutesUsed, timeSavedSeconds }) => {
        setMessageCount(messageCount)
        setMinutesUsed(minutesUsed)
        setTimeSavedSeconds(timeSavedSeconds)
      })
      .finally(() => setLoading(false))
  }, [])

  const msgPct = Math.min((messageCount / DAILY_MESSAGE_CAP) * 100, 100)
  const minPct = Math.min((minutesUsed / DAILY_MINUTE_CAP) * 100, 100)
  const timeSavedMin = Math.floor(timeSavedSeconds / 60)
  const timeSavedSec = timeSavedSeconds % 60
  const isNearLimit = messageCount >= DAILY_MESSAGE_CAP - 2 || minutesUsed >= DAILY_MINUTE_CAP - 1

  return (
    <Box
      w="full"
      position="relative"
      p={{ base: "5", md: "7" }}
      css={{
        borderRadius: "1.25rem",
        background: "linear-gradient(135deg, #ffffff 0%, #f1f5f9 60%, #e8f0fe 100%)",
        border: "1.5px solid rgba(255,255,255,0.9)",
        boxShadow: "0 8px 40px rgba(255,255,255,0.22), 0 2px 12px rgba(99,102,241,0.18), 0 0 0 1px rgba(255,255,255,0.4)",
      }}
    >
      {/* Subtle shimmer overlay */}
      <Box
        position="absolute" inset={0} pointerEvents="none"
        css={{
          borderRadius: "1.25rem",
          background: "linear-gradient(120deg, rgba(255,255,255,0.6) 0%, transparent 60%)",
        }}
      />

      <VStack align="flex-start" gap="5" position="relative">

        {/* Header */}
        <HStack justify="space-between" w="full" align="flex-start">
          <HStack gap="3">
            <Box
              w="11" h="11" borderRadius="xl"
              display="flex" alignItems="center" justifyContent="center"
              css={{
                background: "linear-gradient(135deg, #6366f1, #4f46e5)",
                boxShadow: "0 4px 14px rgba(99,102,241,0.45)",
              }}
            >
              <Icon boxSize="5" color="white"><LuActivity /></Icon>
            </Box>
            <VStack align="flex-start" gap="0">
              <Heading size="sm" fontWeight="bold" color="gray.800" letterSpacing="tight">
                User Activity
              </Heading>
              <Text fontSize="xs" color="gray.500" fontWeight="medium">Daily usage · Free plan</Text>
            </VStack>
          </HStack>
          <Badge
            px="2.5" py="1" borderRadius="full"
            css={{
              background: "linear-gradient(135deg, #f59e0b, #d97706)",
              color: "white",
              fontSize: "10px",
              fontWeight: "800",
              letterSpacing: "0.07em",
              boxShadow: "0 2px 8px rgba(245,158,11,0.4)",
            }}
          >
            FREE
          </Badge>
        </HStack>

        {/* Usage meters */}
        <VStack gap="3" w="full">
          <UsageMeter
            icon={<LuMessageSquare />}
            label="Messages"
            current={messageCount}
            cap={DAILY_MESSAGE_CAP}
            pct={msgPct}
            unit="msgs"
            accentFrom="#6366f1"
            accentTo="#818cf8"
            loading={loading}
          />
          <UsageMeter
            icon={<LuClock />}
            icon2={<LuActivity />}
            label="Session Time"
            current={Math.round(minutesUsed * 10) / 10}
            cap={DAILY_MINUTE_CAP}
            pct={minPct}
            unit="min"
            accentFrom="#0ea5e9"
            accentTo="#38bdf8"
            loading={loading}
          />
        </VStack>

        {/* Time Saved counter */}
        <Box
          w="full" p="3.5" borderRadius="xl"
          css={{
            background: "linear-gradient(135deg, rgba(16,185,129,0.1) 0%, rgba(5,150,105,0.08) 100%)",
            border: "1px solid rgba(16,185,129,0.25)",
          }}
        >
          <HStack justify="space-between">
            <HStack gap="2.5">
              <Box
                w="8" h="8" borderRadius="lg"
                display="flex" alignItems="center" justifyContent="center"
                css={{ background: "linear-gradient(135deg, #10b981, #059669)", boxShadow: "0 2px 8px rgba(16,185,129,0.4)" }}
              >
                <Icon boxSize="4" color="white"><LuTrendingUp /></Icon>
              </Box>
              <VStack align="flex-start" gap="0">
                <Text fontSize="xs" color="gray.500" fontWeight="semibold" textTransform="uppercase" letterSpacing="wide">
                  Time Saved Today
                </Text>
                <Text fontSize="xs" color="gray.400">vs. manual drafting</Text>
              </VStack>
            </HStack>
            <VStack align="flex-end" gap="0">
              <Text fontSize="2xl" fontWeight="black" color="green.600" lineHeight="1">
                {loading ? "—" : timeSavedMin > 0 ? `${timeSavedMin}m ${timeSavedSec}s` : `${timeSavedSec}s`}
              </Text>
              <Text fontSize="xs" color="green.500" fontWeight="semibold">saved</Text>
            </VStack>
          </HStack>
        </Box>

        {/* Premium upgrade CTA */}
        <Box
          w="full" p="4" borderRadius="xl"
          css={{
            background: isNearLimit
              ? "linear-gradient(135deg, rgba(245,158,11,0.12), rgba(217,119,6,0.08))"
              : "linear-gradient(135deg, rgba(99,102,241,0.08), rgba(79,70,229,0.05))",
            border: isNearLimit
              ? "1px solid rgba(245,158,11,0.35)"
              : "1px solid rgba(99,102,241,0.2)",
          }}
        >
          {isNearLimit && (
            <HStack gap="1.5" mb="2.5">
              <Box w="2" h="2" borderRadius="full" css={{ background: "#f59e0b", animation: "pulse 1s infinite" }} />
              <Text fontSize="xs" fontWeight="bold" color="orange.600" letterSpacing="wide" textTransform="uppercase">
                Approaching daily limit
              </Text>
            </HStack>
          )}
          <HStack gap="3" mb="3" align="flex-start">
            <Box
              w="8" h="8" borderRadius="lg" flexShrink={0}
              display="flex" alignItems="center" justifyContent="center"
              css={{
                background: "linear-gradient(135deg, #f59e0b, #d97706)",
                boxShadow: "0 2px 8px rgba(245,158,11,0.5)",
              }}
            >
              <Icon boxSize="4" color="white"><LuCrown /></Icon>
            </Box>
            <VStack align="flex-start" gap="0.5">
              <Text fontSize="sm" fontWeight="bold" color="gray.800">Upgrade to Premium</Text>
              <Text fontSize="xs" color="gray.500">Unlimited messages · Unlimited sessions · Priority AI speed</Text>
            </VStack>
          </HStack>
          <VStack gap="1.5" align="flex-start" mb="3">
            {[
              "Unlimited daily messages",
              "Unlimited session time",
              "Memory across all sessions",
              "Priority Cerebras speed",
            ].map(feat => (
              <HStack key={feat} gap="2">
                <Box
                  w="4" h="4" borderRadius="full" flexShrink={0}
                  display="flex" alignItems="center" justifyContent="center"
                  css={{ background: "linear-gradient(135deg, #f59e0b, #d97706)" }}
                >
                  <Icon boxSize="2.5" color="white"><LuCheck /></Icon>
                </Box>
                <Text fontSize="xs" color="gray.600" fontWeight="medium">{feat}</Text>
              </HStack>
            ))}
          </VStack>
          <Box
            as="button"
            w="full" py="2.5" borderRadius="xl"
            display="flex" alignItems="center" justifyContent="center" gap="2"
            cursor="pointer" transition="all 0.2s"
            css={{
              background: "linear-gradient(135deg, #f59e0b, #d97706)",
              color: "white",
              fontWeight: "800",
              fontSize: "0.8rem",
              letterSpacing: "0.07em",
              textTransform: "uppercase",
              boxShadow: "0 4px 16px rgba(245,158,11,0.45)",
              "&:hover": {
                boxShadow: "0 6px 24px rgba(245,158,11,0.65)",
                transform: "translateY(-1px)",
              },
            }}
          >
            <Icon boxSize="4"><LuZap /></Icon>
            UNLOCK PREMIUM
          </Box>
        </Box>

      </VStack>
    </Box>
  )
}

function UsageMeter({
  icon,
  label,
  current,
  cap,
  pct,
  unit,
  accentFrom,
  accentTo,
  loading,
}: {
  icon: React.ReactNode
  icon2?: React.ReactNode
  label: string
  current: number
  cap: number
  pct: number
  unit: string
  accentFrom: string
  accentTo: string
  loading: boolean
}) {
  const isOver = pct >= 100
  const isWarn = pct >= 70

  return (
    <Box w="full">
      <HStack justify="space-between" mb="1.5">
        <HStack gap="2">
          <Icon boxSize="3.5" css={{ color: isOver ? "#ef4444" : isWarn ? "#f59e0b" : "#6366f1" }}>
            {icon}
          </Icon>
          <Text fontSize="xs" fontWeight="semibold" color="gray.600" letterSpacing="wide" textTransform="uppercase">
            {label}
          </Text>
        </HStack>
        <HStack gap="1" align="baseline">
          <Text
            fontSize="sm" fontWeight="black"
            css={{ color: isOver ? "#ef4444" : isWarn ? "#f59e0b" : "#4f46e5" }}
          >
            {loading ? "—" : current}
          </Text>
          <Text fontSize="xs" color="gray.400" fontWeight="medium">/ {cap} {unit}</Text>
        </HStack>
      </HStack>

      {/* Progress bar track */}
      <Box w="full" h="6px" borderRadius="full" bg="gray.200" overflow="hidden">
        <Box
          h="full" borderRadius="full"
          transition="width 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)"
          css={{
            width: loading ? "0%" : `${pct}%`,
            background: isOver
              ? "linear-gradient(90deg, #ef4444, #dc2626)"
              : isWarn
              ? "linear-gradient(90deg, #f59e0b, #d97706)"
              : `linear-gradient(90deg, ${accentFrom}, ${accentTo})`,
            boxShadow: isOver
              ? "0 0 8px rgba(239,68,68,0.5)"
              : isWarn
              ? "0 0 8px rgba(245,158,11,0.4)"
              : `0 0 8px ${accentFrom}60`,
          }}
        />
      </Box>

      {isOver && (
        <Text fontSize="xs" color="red.500" fontWeight="semibold" mt="1">
          Daily limit reached · Upgrade for unlimited access
        </Text>
      )}
    </Box>
  )
}
