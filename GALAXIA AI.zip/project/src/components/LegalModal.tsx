import { Box, VStack, HStack, Text, Heading, Icon } from "@chakra-ui/react"
import { LuX, LuShield, LuFileText } from "react-icons/lu"

type Page = "terms" | "privacy"

interface LegalModalProps {
  page: Page
  onClose: () => void
}

const TERMS_CONTENT = `Last updated: June 2026

1. ACCEPTANCE OF TERMS
By accessing or using GALAXIA AI ("the Service"), you agree to be bound by these Terms of Service. If you do not agree, do not use the Service.

2. DESCRIPTION OF SERVICE
GALAXIA AI is a real-time communication and negotiation intelligence tool. All processing occurs ephemerally — no conversation data is stored.

3. USER RESPONSIBILITIES
You are solely responsible for all outcomes and consequences. You must not use the Service for illegal, harmful, or malicious purposes.

4. AI SUGGESTION DISCLAIMER
Suggestions are not professional legal, medical, financial, psychological, or relationship advice. They are AI-generated text. You retain full responsibility for any action taken.

5. MICROPHONE & DATA ACCESS
When using voice features, you grant permission for microphone access for real-time speech processing only. Audio is processed in-browser and never transmitted to or stored on any server.

6. INTELLECTUAL PROPERTY
The GALAXIA AI platform and branding are proprietary. AI suggestions are provided "as-is" with no warranty of accuracy or fitness for purpose.

7. LIMITATION OF LIABILITY
TO THE FULLEST EXTENT PERMITTED BY LAW, GALAXIA AI AND ITS OPERATORS ACCEPT NO LIABILITY FOR ANY DAMAGES ARISING FROM YOUR USE OF THE SERVICE.

8. INDEMNIFICATION
You agree to indemnify and hold harmless GALAXIA AI and its operators from any claims arising from your use or violation of these terms.

9. MODIFICATIONS
These terms may be updated at any time. Continued use constitutes acceptance.

10. GOVERNING LAW
Disputes will be resolved through binding arbitration under applicable law.`

const PRIVACY_CONTENT = `Last updated: June 2026

SUMMARY: GALAXIA AI operates on a strict zero-storage policy. We do not collect, store, or sell your personal data.

1. WHAT WE COLLECT
We do not collect personal information. Conversation text and voice data is processed in real-time only and immediately discarded — nothing is retained.

2. EMAIL & ACCOUNT DATA
If you sign in via Google, your email is stored securely in Supabase solely for authentication. We never sell, share, or use it for marketing.

3. VOICE & AUDIO DATA
Audio is processed by your browser's built-in Speech Recognition API (Google/Apple per your browser). Audio does not pass through GALAXIA AI servers and is never recorded.

4. CONVERSATION DATA
Text and transcriptions are sent to our AI API provider (Cerebras / Groq) transiently for generating a response. This data is not retained by GALAXIA AI beyond a single API call.

5. LOCAL STORAGE
A session identifier may be stored in localStorage to maintain session continuity. This is a random ID with no personal information. It clears when you clear browser data.

6. COOKIES & TRACKING
We do not use tracking cookies, third-party analytics, or behavioral tracking.

7. DATA SECURITY
We use HTTPS/TLS encryption and security-hardened infrastructure via Supabase. No system is 100% secure; you use the Service at your own risk.

8. DATA BREACH NOTIFICATION
In the unlikely event of a breach affecting your stored email, we will notify you within 72 hours.

9. YOUR RIGHTS
You may request deletion of your account and email at any time. There is no other personal data to delete.

10. THIRD-PARTY SERVICES
- Supabase: backend database and authentication
- Cerebras AI: LLM inference
- Groq: LLM inference fallback
- Browser Speech API: voice-to-text (browser-native, no GALAXIA server involved)

11. CONTACT
For privacy inquiries or data deletion requests, contact us through the app's support channel.`

export default function LegalModal({ page, onClose }: LegalModalProps) {
  const isTerms = page === "terms"
  const accentColor = isTerms ? "#60a5fa" : "#34d399"
  const accentBorder = isTerms ? "rgba(59,130,246,0.3)" : "rgba(52,211,153,0.3)"
  const shadowColor = isTerms ? "rgba(59,130,246,0.2)" : "rgba(52,211,153,0.15)"

  return (
    <Box
      position="fixed" inset={0} zIndex="modal"
      display="flex" alignItems="center" justifyContent="center"
      css={{ backdropFilter: "blur(14px)", background: "rgba(0,0,0,0.85)" }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <Box w="92%" maxW="600px" maxH="88vh"
        display="flex" flexDirection="column"
        css={{
          background: "rgba(4,3,20,0.99)",
          border: `1px solid ${accentBorder}`,
          borderRadius: "1.5rem",
          boxShadow: `0 0 60px ${shadowColor}, 0 0 120px ${shadowColor}`,
        }}
      >
        {/* Header */}
        <Box p="5" css={{ borderBottom: `1px solid ${accentBorder}` }}>
          <HStack justify="space-between">
            <HStack gap="3">
              <Box w="10" h="10" borderRadius="xl"
                display="flex" alignItems="center" justifyContent="center"
                css={{ background: `${accentColor}18`, border: `1px solid ${accentBorder}`, boxShadow: `0 0 14px ${shadowColor}` }}>
                <Icon boxSize="5" css={{ color: accentColor }}>
                  {isTerms ? <LuFileText /> : <LuShield />}
                </Icon>
              </Box>
              <VStack align="flex-start" gap="0">
                <Heading size="sm" color="white">
                  {isTerms ? "Terms of Service" : "Privacy Policy"}
                </Heading>
                <Text fontSize="xs" color="gray.400">
                  {isTerms ? "Please read before using GALAXIA AI" : "How we handle your data"}
                </Text>
              </VStack>
            </HStack>
            <Box as="button" onClick={onClose} w="7" h="7" borderRadius="full"
              display="flex" alignItems="center" justifyContent="center" cursor="pointer"
              css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", "&:hover": { background: "rgba(255,255,255,0.1)" } }}>
              <Icon boxSize="3.5" color="gray.400"><LuX /></Icon>
            </Box>
          </HStack>
        </Box>

        {/* Scrollable content */}
        <Box flex={1} overflow="auto" p="6"
          css={{ scrollbarWidth: "thin", scrollbarColor: `${accentColor}40 transparent` }}>
          <VStack align="stretch" gap="5">
            {(isTerms ? TERMS_CONTENT : PRIVACY_CONTENT).split("\n\n").map((section, i) => {
              const isHeading = /^\d+\./.test(section) || section.startsWith("SUMMARY:")
              if (isHeading) {
                const [title, ...body] = section.split("\n")
                return (
                  <Box key={i}>
                    <Text fontSize="xs" fontWeight="bold" letterSpacing="wider" textTransform="uppercase" mb="1.5"
                      css={{ color: accentColor, textShadow: `0 0 8px ${accentColor}60` }}>
                      {title}
                    </Text>
                    {body.length > 0 && <Text fontSize="sm" color="gray.300" lineHeight="tall">{body.join("\n")}</Text>}
                  </Box>
                )
              }
              return <Text key={i} fontSize="sm" color="gray.400" lineHeight="tall">{section}</Text>
            })}
          </VStack>
        </Box>

        {/* Footer */}
        <Box p="4" css={{ borderTop: `1px solid ${accentBorder}` }}>
          <Box as="button" w="full" py="2.5" borderRadius="xl" cursor="pointer"
            display="flex" alignItems="center" justifyContent="center"
            transition="all 0.2s"
            css={{
              background: `${accentColor}18`,
              border: `1px solid ${accentBorder}`,
              color: accentColor,
              fontWeight: "700", fontSize: "0.8rem", letterSpacing: "0.08em",
              "&:hover": { background: accentBorder },
            }}
            onClick={onClose}>
            CLOSE
          </Box>
        </Box>
      </Box>
    </Box>
  )
}
