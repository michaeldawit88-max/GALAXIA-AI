import { useState } from "react"
import { Box, VStack, HStack, Text, Heading, Button, Icon } from "@chakra-ui/react"
import { LuShield, LuChevronDown, LuChevronUp, LuCheck, LuX } from "react-icons/lu"
import { ASSISTANTS, type AssistantId } from "@/App"

interface TermsModalProps {
  assistantId: AssistantId
  onAgree: () => void
  onDecline: () => void
}

const TERMS_TEXT = `TERMS OF USE & PRIVACY AGREEMENT

By activating this AI assistant, you explicitly acknowledge and agree to the following:

1. FULL USER RESPONSIBILITY
You take full responsibility for all outcomes, decisions, and consequences resulting from your use of this AI assistant. GALAXIA AI, its owners, developers, and team members bear no liability for any losses, damages, missed opportunities, or unintended consequences arising from suggestions provided.

2. AUDIO & DATA ACCESS PERMISSION
You grant explicit permission for this assistant to access microphone audio, on-screen text, and conversation data solely for real-time processing. This access is used exclusively for generating AI suggestions and is not stored, transmitted, or shared with any third party.

3. ZERO DATA RETENTION POLICY
GALAXIA AI operates on a strict zero-storage policy. All conversation data, audio, text, and context information is processed ephemerally and immediately discarded after each session. No user data, conversation history, or personally identifiable information is ever stored.

4. PRIVACY & DATA BREACH LIABILITY
While every technical precaution is taken to protect your privacy, GALAXIA AI, its owners, developers, and team members accept no liability for any privacy breaches, data leaks, or unauthorized access that may occur as a result of using this service. You use this service entirely at your own risk.

5. NO PROFESSIONAL ADVICE
AI suggestions are not professional legal, medical, financial, or psychological advice. Always use your own judgment.

6. ACCEPTABLE USE
You agree not to use this AI for illegal, harmful, or malicious purposes. Misuse is solely your responsibility.

7. INTELLECTUAL PROPERTY
All AI responses are generated suggestions only and carry no warranty of accuracy, completeness, or fitness for purpose.

By clicking "I AGREE", you confirm you have read, understood, and accepted all terms above.`

export default function TermsModal({ assistantId, onAgree, onDecline }: TermsModalProps) {
  const [expanded, setExpanded] = useState(false)
  const [accepted, setAccepted] = useState(false)
  const assistant = ASSISTANTS.find(a => a.id === assistantId)!

  return (
    <Box
      position="fixed"
      inset={0}
      zIndex="overlay"
      display="flex"
      alignItems="center"
      justifyContent="center"
      css={{ backdropFilter: "blur(10px)", background: "rgba(0,0,0,0.8)" }}
    >
      <Box
        css={{
          background: "#050505",
          border: "1px solid rgba(59,130,246,0.4)",
          borderRadius: "1.5rem",
          boxShadow: "0 0 60px rgba(59,130,246,0.25), 0 0 120px rgba(59,130,246,0.1)",
        }}
        maxW="520px"
        w="92%"
        maxH="90vh"
        overflow="hidden"
        display="flex"
        flexDirection="column"
      >
        {/* Header */}
        <Box p="6" css={{ borderBottom: "1px solid rgba(59,130,246,0.2)" }}>
          <HStack gap="3" mb="2">
            <Box
              w="10"
              h="10"
              borderRadius="xl"
              display="flex"
              alignItems="center"
              justifyContent="center"
              css={{
                background: "rgba(59,130,246,0.15)",
                border: "1px solid rgba(59,130,246,0.4)",
                boxShadow: "0 0 15px rgba(59,130,246,0.4)",
              }}
            >
              <Icon color="blue.300" boxSize="5"><LuShield /></Icon>
            </Box>
            <VStack align="flex-start" gap="0">
              <Heading size="sm" color="white">Activate {assistant.title}</Heading>
              <Text fontSize="xs" color="gray.400">Review terms before proceeding</Text>
            </VStack>
          </HStack>
        </Box>

        {/* Terms toggle */}
        <Box px="6" pt="4">
          <Box
            as="button"
            w="full"
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            onClick={() => setExpanded(!expanded)}
            px="3"
            py="2"
            borderRadius="lg"
            cursor="pointer"
            css={{
              color: "#60a5fa",
              fontSize: "0.875rem",
              fontWeight: "500",
              border: "1px solid rgba(59,130,246,0.2)",
              "&:hover": { background: "rgba(59,130,246,0.1)" },
            }}
          >
            <HStack gap="2">
              <Icon boxSize="4"><LuShield /></Icon>
              <Text fontSize="sm" fontWeight="medium">Terms of Use & Privacy Agreement</Text>
            </HStack>
            <Icon boxSize="4">{expanded ? <LuChevronUp /> : <LuChevronDown />}</Icon>
          </Box>
        </Box>

        {/* Expandable terms */}
        {expanded && (
          <Box
            mx="6"
            mt="2"
            borderRadius="lg"
            overflow="auto"
            maxH="200px"
            p="4"
            css={{
              border: "1px solid rgba(59,130,246,0.15)",
              background: "rgba(0,0,0,0.4)",
              scrollbarWidth: "thin",
              scrollbarColor: "rgba(59,130,246,0.3) transparent",
            }}
          >
            <Text
              fontSize="xs"
              color="gray.400"
              whiteSpace="pre-line"
              lineHeight="tall"
              fontFamily="mono"
            >
              {TERMS_TEXT}
            </Text>
          </Box>
        )}

        {/* Agree checkbox */}
        <Box px="6" pt="4">
          <Box
            as="button"
            onClick={() => setAccepted(!accepted)}
            display="flex"
            alignItems="flex-start"
            gap="3"
            textAlign="left"
            w="full"
            p="3"
            borderRadius="lg"
            cursor="pointer"
            transition="all 0.2s"
            css={{
              background: accepted ? "rgba(59,130,246,0.08)" : "transparent",
              border: `1px solid ${accepted ? "rgba(59,130,246,0.4)" : "rgba(255,255,255,0.08)"}`,
            }}
          >
            <Box
              flexShrink={0}
              w="5"
              h="5"
              borderRadius="md"
              display="flex"
              alignItems="center"
              justifyContent="center"
              mt="0.5"
              transition="all 0.2s"
              css={{
                border: `2px solid ${accepted ? "#60a5fa" : "#4b5563"}`,
                background: accepted ? "#3b82f6" : "transparent",
                boxShadow: accepted ? "0 0 10px rgba(59,130,246,0.6)" : "none",
              }}
            >
              {accepted && <Icon color="white" boxSize="3"><LuCheck /></Icon>}
            </Box>
            <Text fontSize="sm" color={accepted ? "gray.200" : "gray.400"} lineHeight="tall">
              I have read and agree to the Terms of Use & Privacy Agreement. I understand and accept full responsibility for my use of GALAXIA AI.
            </Text>
          </Box>
        </Box>

        {/* Action buttons */}
        <Box p="6" pt="4">
          <HStack gap="3">
            <Button
              flex={1}
              variant="outline"
              borderColor="gray.700"
              color="gray.400"
              _hover={{ bg: "gray.900", borderColor: "gray.600" }}
              onClick={onDecline}
              size="md"
            >
              <Icon boxSize="4"><LuX /></Icon>
              Decline
            </Button>
            <Button
              flex={1}
              size="md"
              fontWeight="bold"
              letterSpacing="wide"
              transition="all 0.3s"
              disabled={!accepted}
              onClick={accepted ? onAgree : undefined}
              css={{
                background: accepted ? "#2563eb" : "#1f2937",
                color: accepted ? "white" : "#4b5563",
                boxShadow: accepted ? "0 0 20px rgba(59,130,246,0.5)" : "none",
                cursor: accepted ? "pointer" : "not-allowed",
                "&:hover": accepted ? { background: "#3b82f6", boxShadow: "0 0 30px rgba(59,130,246,0.8)" } : {},
              }}
            >
              <Icon boxSize="4"><LuCheck /></Icon>
              I AGREE
            </Button>
          </HStack>
        </Box>
      </Box>
    </Box>
  )
}
