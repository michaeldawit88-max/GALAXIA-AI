export default function SpaceBackground() {
  return (
    <div className="space-bg">
      {/* Nebula clouds */}
      <div className="nebula-1" />
      <div className="nebula-2" />
      <div className="nebula-3" />
      <div className="nebula-4" />
      <div className="nebula-5" />

      {/* Star fields - 5 layers for density */}
      <div className="stars-tiny" />
      <div className="stars-small" />
      <div className="stars-small-b" />
      <div className="stars-medium" />
      <div className="stars-medium-b" />
      <div className="stars-large" />

      {/* Shooting stars */}
      <div className="shooting-star" />
      <div className="shooting-star" />
      <div className="shooting-star" />
      <div className="shooting-star" />
      <div className="shooting-star" />
      <div className="shooting-star" />
      <div className="shooting-star" />

      {/* Spiral galaxies - more of them */}
      <div className="galaxy-1" />
      <div className="galaxy-2" />
      <div className="galaxy-3" />
      <div className="galaxy-4" />
      <div className="galaxy-5" />

      {/* Black hole - bottom right */}
      <div className="black-hole">
        <div className="black-hole-glow" />
        <div className="black-hole-disk" />
        <div className="black-hole-core" />
      </div>
    </div>
  )
}
