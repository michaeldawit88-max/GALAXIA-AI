import { useState, useRef, useEffect, useCallback } from "react"
import { Box, VStack, HStack, Text, Icon, Heading } from "@chakra-ui/react"
import {
  LuMic, LuMicOff, LuX, LuCircleAlert, LuCopy, LuCheck, LuRefreshCw,
  LuShieldCheck, LuTriangleAlert,
} from "react-icons/lu"
import { askGalaxia } from "@/lib/ai"
import { FALLBACK_RESPONSE } from "@/lib/speech"

function friendlyError(raw: string): string {
  if (raw.includes("rate limit") || raw.includes("429")) return "Server busy — please try again in a moment."
  if (raw.includes("50") || raw.includes("maintenance")) return "Server is busy, please try again in a moment."
  if (raw.includes("network") || raw.includes("fetch")) return "Connection issue. Check your internet."
  if (raw.includes("not-allowed") || raw.includes("Permission")) return "Microphone access denied. Please allow mic in browser settings."
  return "Server is busy, please try again in a moment."
}

type PermState = "idle" | "requesting" | "granted" | "denied"

interface PhoneAssistantProps {
  onClose: () => void
}

export default function PhoneAssistant({ onClose }: PhoneAssistantProps) {
  const [permState, setPermState] = useState<PermState>("idle")
  const [isListening, setIsListening] = useState(false)
  const [interimText, setInterimText] = useState("")
  const [suggestion, setSuggestion] = useState("")
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [sessionLog, setSessionLog] = useState<string[]>([])

  const streamRef = useRef<MediaStream | null>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const transcriptRef = useRef("")
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const shouldRunRef = useRef(false)
  const historyRef = useRef<Array<{ role: "user" | "assistant"; content: string }>>([])

  // ── Ask AI with full conversation context ──────────────────────────────────
  const queryAI = useCallback(async (transcript: string) => {
    if (!transcript.trim()) return
    setLoading(true)
    setSuggestion("")
    setError("")
    try {
      const result = await askGalaxia({
        mode: "phone",
        userText: `Phone call — what they just said:\n"${transcript}"\n\nFull call so far:\n${transcriptRef.current}\n\nGive me the best thing to say right now.`,
        conversationHistory: historyRef.current,
      })
      const reply = result?.trim() || FALLBACK_RESPONSE
      setSuggestion(reply)
      historyRef.current = [
        ...historyRef.current,
        { role: "user", content: transcript },
        { role: "assistant", content: reply },
      ].slice(-20)
    } catch (e: any) {
      setSuggestion(FALLBACK_RESPONSE)
      setError(friendlyError(e.message ?? ""))
    } finally {
      setLoading(false)
    }
  }, [])

  // ── Build & start SpeechRecognition ───────────────────────────────────────
  const buildRecognition = useCallback(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SR) return null
    const rec = new SR() as SpeechRecognition
    rec.continuous = true
    rec.interimResults = true
    rec.lang = "en-US"
    rec.maxAlternatives = 3

    rec.onresult = (e: SpeechRecognitionEvent) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript
        if (e.results[i].isFinal) {
          setInterimText("")
          const line = t.trim()
          if (!line) continue
          transcriptRef.current = transcriptRef.current ? `${transcriptRef.current}\n${line}` : line
          setSessionLog(prev => [...prev.slice(-15), line])
          if (debounceRef.current) clearTimeout(debounceRef.current)
          debounceRef.current = setTimeout(() => queryAI(line), 700)
        } else {
          setInterimText(t)
        }
      }
    }

    rec.onerror = (e: SpeechRecognitionErrorEvent) => {
      if (e.error === "not-allowed") {
        shouldRunRef.current = false
        setIsListening(false)
        setPermState("denied")
        setError("Microphone access denied. Allow it in your browser settings.")
      }
    }

    rec.onend = () => {
      setIsListening(false)
      if (shouldRunRef.current) {
        setTimeout(() => {
          if (!shouldRunRef.current) return
          try {
            const r2 = buildRecognition()
            if (!r2) return
            recognitionRef.current = r2
            r2.start()
            setIsListening(true)
          } catch {}
        }, 50)
      }
    }
    return rec
  }, [queryAI])

  // ── Request mic permission explicitly ─────────────────────────────────────
  const requestPermission = useCallback(async () => {
    setPermState("requesting")
    setError("")
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false })
      streamRef.current = stream
      setPermState("granted")

      const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      if (!SR) {
        setError("Speech recognition requires Chrome or Edge browser.")
        return
      }

      shouldRunRef.current = true
      const rec = buildRecognition()
      if (!rec) return
      recognitionRef.current = rec
      rec.start()
      setIsListening(true)

      // Play boop: mic is live
      try {
        const ctx = new AudioContext()
        const o = ctx.createOscillator(), g = ctx.createGain()
        o.connect(g); g.connect(ctx.destination)
        o.frequency.setValueAtTime(880, ctx.currentTime)
        o.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.08)
        g.gain.setValueAtTime(0.18, ctx.currentTime)
        g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18)
        o.start(); o.stop(ctx.currentTime + 0.18)
        o.onended = () => ctx.close()
      } catch {}
    } catch (e: any) {
      if (e.name === "NotAllowedError") {
        setPermState("denied")
        setError("Microphone access denied. Click the lock icon in your browser address bar to allow it.")
      } else {
        setPermState("idle")
        setError(`Could not access microphone: ${e.message}`)
      }
    }
  }, [buildRecognition])

  const pauseResume = useCallback(() => {
    if (isListening) {
      shouldRunRef.current = false
      recognitionRef.current?.stop()
      setIsListening(false)
    } else {
      shouldRunRef.current = true
      const rec = buildRecognition()
      if (!rec) return
      recognitionRef.current = rec
      rec.start()
      setIsListening(true)
    }
  }, [isListening, buildRecognition])

  useEffect(() => {
    return () => {
      shouldRunRef.current = false
      recognitionRef.current?.stop()
      streamRef.current?.getTracks().forEach(t => t.stop())
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [])

  const handleCopy = async () => {
    if (!suggestion) return
    await navigator.clipboard.writeText(suggestion).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const accentColor = "#22d3ee"

  // ── Permission gate screen ─────────────────────────────────────────────────
  if (permState === "idle" || permState === "requesting") {
    return (
      <Box position="fixed" inset={0} zIndex="modal"
        display="flex" alignItems="center" justifyContent="center"
        css={{ backdropFilter: "blur(16px)", background: "rgba(0,0,0,0.85)" }}
        onClick={e => e.target === e.currentTarget && onClose()}
      >
        <Box maxW="400px" w="92%" p="8"
          css={{
            background: "rgba(4,3,20,0.98)",
            border: "1px solid rgba(34,211,238,0.4)",
            borderRadius: "1.5rem",
            boxShadow: "0 0 60px rgba(34,211,238,0.2)",
          }}
        >
          <VStack gap="5" textAlign="center">
            <Box w="16" h="16" borderRadius="2xl"
              display="flex" alignItems="center" justifyContent="center"
              css={{
                background: "rgba(34,211,238,0.15)",
                border: "1px solid rgba(34,211,238,0.5)",
                boxShadow: "0 0 30px rgba(34,211,238,0.4)",
              }}
            >
              <Icon boxSize="7" css={{ color: accentColor }}><LuMic /></Icon>
            </Box>
            <VStack gap="2">
              <Heading size="md" color="white">Microphone Access Required</Heading>
              <Text fontSize="sm" color="gray.400" lineHeight="tall">
                GALAXIA AI needs to hear your phone call to generate real-time tactical suggestions. Your audio is processed live — <Text as="span" color={accentColor} fontWeight="semibold">nothing is recorded or stored.</Text>
              </Text>
            </VStack>
            <VStack gap="2" w="full" align="flex-start"
              p="3" borderRadius="xl"
              css={{ background: "rgba(34,211,238,0.06)", border: "1px solid rgba(34,211,238,0.2)" }}
            >
              {["Audio processed locally — never saved", "Session ends when you close", "No recordings, no uploads"].map(item => (
                <HStack key={item} gap="2">
                  <Icon boxSize="3.5" css={{ color: accentColor }}><LuShieldCheck /></Icon>
                  <Text fontSize="xs" color="gray.300">{item}</Text>
                </HStack>
              ))}
            </VStack>
            {error && (
              <HStack gap="2" p="3" borderRadius="lg" w="full"
                css={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.3)" }}>
                <Icon boxSize="4" css={{ color: "#f87171" }}><LuTriangleAlert /></Icon>
                <Text fontSize="xs" color="red.300">{error}</Text>
              </HStack>
            )}
            <HStack gap="3" w="full">
              <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                css={{
                  background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                  color: "#9ca3af", fontSize: "13px", fontWeight: "700",
                  "&:hover": { background: "rgba(255,255,255,0.1)" },
                }}
                onClick={onClose}
              >
                Cancel
              </Box>
              <Box as="button" flex={2} py="2.5" borderRadius="xl" cursor="pointer"
                display="flex" alignItems="center" justifyContent="center" gap="2"
                onClick={permState === "idle" ? requestPermission : undefined}
                css={{
                  background: permState === "requesting"
                    ? "rgba(34,211,238,0.2)"
                    : "linear-gradient(135deg, #0891b2, #22d3ee)",
                  border: "1px solid rgba(34,211,238,0.6)",
                  color: "white", fontSize: "13px", fontWeight: "800", letterSpacing: "0.06em",
                  boxShadow: "0 0 20px rgba(34,211,238,0.4)",
                  cursor: permState === "requesting" ? "wait" : "pointer",
                }}
              >
                {permState === "requesting" ? (
                  <>
                    <Box w="4" h="4" borderRadius="full"
                      css={{ border: "2px solid rgba(34,211,238,0.3)", borderTop: "2px solid #22d3ee", animation: "spin 0.8s linear infinite" }} />
                    Requesting...
                  </>
                ) : (
                  <><Icon boxSize="4"><LuMic /></Icon> ALLOW MICROPHONE</>
                )}
              </Box>
            </HStack>
          </VStack>
        </Box>
      </Box>
    )
  }

  if (permState === "denied") {
    return (
      <Box position="fixed" inset={0} zIndex="modal"
        display="flex" alignItems="center" justifyContent="center"
        css={{ backdropFilter: "blur(16px)", background: "rgba(0,0,0,0.85)" }}
        onClick={e => e.target === e.currentTarget && onClose()}
      >
        <Box maxW="380px" w="92%" p="7"
          css={{
            background: "rgba(4,3,20,0.98)",
            border: "1px solid rgba(239,68,68,0.4)",
            borderRadius: "1.5rem",
            boxShadow: "0 0 40px rgba(239,68,68,0.2)",
          }}
        >
          <VStack gap="4" textAlign="center">
            <Icon boxSize="10" css={{ color: "#f87171" }}><LuTriangleAlert /></Icon>
            <Heading size="sm" color="white">Microphone Blocked</Heading>
            <Text fontSize="sm" color="gray.400" lineHeight="tall">
              Click the <Text as="span" color="white" fontWeight="bold">lock icon</Text> in your browser's address bar → Site Settings → Microphone → Allow. Then reload and try again.
            </Text>
            <HStack gap="3" w="full">
              <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                css={{
                  background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.4)",
                  color: "#fca5a5", fontSize: "13px", fontWeight: "700",
                }}
                onClick={() => { setPermState("idle"); setError("") }}
              >
                Try Again
              </Box>
              <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                css={{
                  background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                  color: "#9ca3af", fontSize: "13px", fontWeight: "700",
                }}
                onClick={onClose}
              >
                Close
              </Box>
            </HStack>
          </VStack>
        </Box>
      </Box>
    )
  }

  // ── Active listening overlay ───────────────────────────────────────────────
  return (
    <Box
      position="fixed" bottom={0} left={0} right={0} zIndex="modal"
      css={{
        backdropFilter: "blur(24px) saturate(1.5)",
        background: "linear-gradient(to top, rgba(8,145,178,0.18) 0%, rgba(8,145,178,0.08) 100%)",
        borderTop: "2px solid #22d3ee",
        boxShadow: "0 -4px 40px rgba(34,211,238,0.4)",
        animation: "slideFromBottom 0.4s cubic-bezier(0.16, 1, 0.3, 1)",
        maxHeight: "36vh",
      }}
    >
      <Box h="1px" css={{ background: "linear-gradient(90deg, transparent, #22d3ee, transparent)", boxShadow: "0 0 12px #22d3ee" }} />
      <Box p="4" display="flex" flexDirection="column" gap="3" maxH="34vh" overflowY="auto">

        {/* Header */}
        <HStack justify="space-between">
          <HStack gap="2">
            <Box w="7" h="7" borderRadius="full" display="flex" alignItems="center" justifyContent="center"
              css={{
                background: isListening ? "rgba(34,211,238,0.25)" : "rgba(34,211,238,0.1)",
                border: "1px solid #22d3ee",
                boxShadow: isListening ? "0 0 14px rgba(34,211,238,0.7)" : "0 0 6px rgba(34,211,238,0.3)",
              }}>
              <Icon boxSize="3.5" css={{ color: accentColor }}>{isListening ? <LuMic /> : <LuMicOff />}</Icon>
            </Box>
            <HStack gap="1.5">
              <Text fontSize="xs" fontWeight="bold" letterSpacing="widest" textTransform="uppercase"
                css={{ color: accentColor, textShadow: "0 0 8px #22d3ee80" }}>PHONE CALL AI</Text>
              {isListening && <Box w="4px" h="4px" borderRadius="full" css={{ background: accentColor, animation: "pulse 1s infinite" }} />}
              <Text fontSize="xs" color="gray.400" textTransform="uppercase" letterSpacing="wide">
                {loading ? "PROCESSING..." : isListening ? "LISTENING LIVE" : "PAUSED"}
              </Text>
            </HStack>
          </HStack>
          <HStack gap="2">
            <Box as="button" onClick={pauseResume}
              px="3" py="1" borderRadius="lg" cursor="pointer"
              display="flex" alignItems="center" gap="1.5"
              css={{
                background: isListening ? "rgba(239,68,68,0.15)" : "rgba(34,211,238,0.15)",
                border: `1px solid ${isListening ? "rgba(239,68,68,0.4)" : "rgba(34,211,238,0.4)"}`,
                color: isListening ? "#f87171" : accentColor,
                fontSize: "11px", fontWeight: "700", letterSpacing: "0.08em",
              }}>
              <Icon boxSize="3">{isListening ? <LuMicOff /> : <LuMic />}</Icon>
              {isListening ? "PAUSE" : "RESUME"}
            </Box>
            <Box as="button" onClick={onClose} w="6" h="6" borderRadius="full"
              display="flex" alignItems="center" justifyContent="center" cursor="pointer"
              css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", "&:hover": { background: "rgba(255,255,255,0.1)" } }}>
              <Icon boxSize="3" color="gray.400"><LuX /></Icon>
            </Box>
          </HStack>
        </HStack>

        {/* Live transcript */}
        {(sessionLog.length > 0 || interimText) && (
          <Box p="2.5" borderRadius="lg"
            css={{ background: "rgba(0,0,0,0.3)", border: "1px solid rgba(34,211,238,0.15)" }}>
            <Text fontSize="xs" color="gray.500" textTransform="uppercase" letterSpacing="wider" mb="1">Hearing</Text>
            <Text fontSize="sm" color="gray.300" lineHeight="tall">
              {sessionLog.slice(-2).join(" ")}
              {interimText && <Box as="span" color="gray.500" fontStyle="italic"> {interimText}</Box>}
            </Text>
          </Box>
        )}

        {error && (
          <HStack gap="2">
            <Icon boxSize="4" css={{ color: "#f87171" }}><LuCircleAlert /></Icon>
            <Text fontSize="sm" color="red.300">{error}</Text>
          </HStack>
        )}

        {/* AI suggestion */}
        {(loading || suggestion) && (
          <Box p="3" borderRadius="xl"
            css={{ background: "rgba(34,211,238,0.08)", border: "1px solid rgba(34,211,238,0.4)", boxShadow: "0 0 16px rgba(34,211,238,0.2)" }}>
            <HStack justify="space-between" mb="2">
              <HStack gap="1.5">
                <Box w="2" h="2" borderRadius="full" css={{ background: accentColor, animation: "pulse 1.5s infinite" }} />
                <Text fontSize="xs" fontWeight="bold" letterSpacing="widest" textTransform="uppercase" css={{ color: accentColor }}>
                  {loading ? "ANALYZING..." : "SAY THIS NOW"}
                </Text>
              </HStack>
              {suggestion && !loading && (
                <Box as="button" onClick={handleCopy} display="flex" alignItems="center" gap="1.5"
                  px="2" py="0.5" borderRadius="md" cursor="pointer"
                  css={{
                    background: copied ? "rgba(34,211,238,0.2)" : "rgba(255,255,255,0.05)",
                    border: `1px solid ${copied ? accentColor : "rgba(255,255,255,0.1)"}`,
                    color: copied ? accentColor : "#9ca3af", fontSize: "11px", fontWeight: "600",
                  }}>
                  <Icon boxSize="3">{copied ? <LuCheck /> : <LuCopy />}</Icon>
                  <Box as="button" onClick={handleCopy} display="flex" alignItems="center" gap="1"
                    css={{ color: "inherit", fontSize: "inherit", background: "none", border: "none", cursor: "pointer" }}>
                    {copied ? "Copied" : "Copy"}
                  </Box>
                </Box>
              )}
            </HStack>
            {loading ? (
              <HStack gap="2">{[0,1,2].map(i => (
                <Box key={i} w="5px" h="5px" borderRadius="full"
                  css={{ background: accentColor, animation: `bounce 0.8s ease-in-out ${i * 0.15}s infinite` }} />
              ))}</HStack>
            ) : (
              <Text fontSize="md" color="white" fontWeight="semibold" lineHeight="short">{suggestion}</Text>
            )}
          </Box>
        )}

        {isListening && !loading && !suggestion && sessionLog.length === 0 && (
          <HStack gap="1.5" justify="center" opacity={0.5}>
            {[0,1,2,3,4].map(i => (
              <Box key={i} w="3px" borderRadius="full"
                css={{ background: accentColor, animation: `soundWave 0.8s ease-in-out ${i * 0.1}s infinite alternate`, height: `${8 + i * 4}px` }} />
            ))}
          </HStack>
        )}
      </Box>
    </Box>
  )
}
