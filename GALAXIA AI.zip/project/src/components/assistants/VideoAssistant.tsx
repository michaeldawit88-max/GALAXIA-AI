import { useState, useRef, useEffect, useCallback } from "react"
import { Box, VStack, HStack, Text, Icon, Heading } from "@chakra-ui/react"
import {
  LuMic, LuMicOff, LuMonitor, LuX, LuCircleAlert, LuCopy, LuCheck,
  LuShieldCheck, LuTriangleAlert, LuMonitorOff,
} from "react-icons/lu"
import { askGalaxia } from "@/lib/ai"
import { FALLBACK_RESPONSE } from "@/lib/speech"

function friendlyError(raw: string): string {
  if (raw.includes("rate limit") || raw.includes("429")) return "Server busy — please try again in a moment."
  if (raw.includes("50") || raw.includes("maintenance")) return "Server is busy, please try again in a moment."
  if (raw.includes("network") || raw.includes("fetch")) return "Connection issue. Check your internet."
  if (raw.includes("not-allowed") || raw.includes("Permission")) return "Permission denied. Allow microphone and screen sharing in browser settings."
  return "Server is busy, please try again in a moment."
}

type PermState = "idle" | "requesting" | "granted" | "denied"

interface VideoAssistantProps {
  onClose: () => void
}

export default function VideoAssistant({ onClose }: VideoAssistantProps) {
  const [permState, setPermState] = useState<PermState>("idle")
  const [micGranted, setMicGranted] = useState(false)
  const [screenGranted, setScreenGranted] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [interimText, setInterimText] = useState("")
  const [suggestion, setSuggestion] = useState("")
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [sessionLog, setSessionLog] = useState<string[]>([])

  const micStreamRef = useRef<MediaStream | null>(null)
  const screenStreamRef = useRef<MediaStream | null>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const shouldRunRef = useRef(false)
  const transcriptRef = useRef("")
  const historyRef = useRef<Array<{ role: "user" | "assistant"; content: string }>>([])

  const accentColor = "#c084fc"

  const queryAI = useCallback(async (text: string) => {
    setLoading(true)
    setSuggestion("")
    setError("")
    try {
      const result = await askGalaxia({
        mode: "video",
        userText: `Video call — recent audio:\n"${text}"\n\nFull transcript:\n${transcriptRef.current.slice(-600)}\n\nWhat should I say?`,
        conversationHistory: historyRef.current,
      })
      const reply = result?.trim() || FALLBACK_RESPONSE
      setSuggestion(reply)
      historyRef.current = [
        ...historyRef.current,
        { role: "user", content: text },
        { role: "assistant", content: reply },
      ].slice(-16)
    } catch (e: any) {
      setSuggestion(FALLBACK_RESPONSE)
      setError(friendlyError(e.message ?? ""))
    } finally {
      setLoading(false)
    }
  }, [])

  const buildRecognition = useCallback(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SR) return null
    const rec = new SR() as SpeechRecognition
    rec.continuous = true
    rec.interimResults = true
    rec.lang = "en-US"

    rec.onresult = (e: SpeechRecognitionEvent) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript
        if (e.results[i].isFinal) {
          setInterimText("")
          const line = t.trim()
          if (!line) continue
          transcriptRef.current = transcriptRef.current ? `${transcriptRef.current}\n${line}` : line
          setSessionLog(prev => [...prev.slice(-12), line])
          if (debounceRef.current) clearTimeout(debounceRef.current)
          debounceRef.current = setTimeout(() => queryAI(line), 700)
        } else {
          setInterimText(t)
        }
      }
    }
    rec.onerror = (e: SpeechRecognitionErrorEvent) => {
      if (e.error === "not-allowed") { shouldRunRef.current = false; setIsListening(false); setPermState("denied") }
    }
    rec.onend = () => {
      setIsListening(false)
      if (shouldRunRef.current) {
        setTimeout(() => {
          if (!shouldRunRef.current) return
          try { const r2 = buildRecognition(); if (!r2) return; recognitionRef.current = r2; r2.start(); setIsListening(true) } catch {}
        }, 50)
      }
    }
    return rec
  }, [queryAI])

  const startListening = useCallback(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SR) { setError("Speech recognition requires Chrome or Edge."); return }
    shouldRunRef.current = true
    const rec = buildRecognition()
    if (!rec) return
    recognitionRef.current = rec
    rec.start()
    setIsListening(true)
  }, [buildRecognition])

  const requestPermissions = useCallback(async () => {
    setPermState("requesting")
    setError("")
    let micOk = false, screenOk = false

    // Step 1: Microphone
    try {
      const micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false })
      micStreamRef.current = micStream
      micOk = true
      setMicGranted(true)
    } catch (e: any) {
      setPermState(e.name === "NotAllowedError" ? "denied" : "idle")
      setError("Microphone access denied. Please allow mic in browser settings.")
      return
    }

    // Step 2: Screen capture (with system audio if available)
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true, // captures system/tab audio on Chrome — lets AI hear both sides
      })
      screenStreamRef.current = screenStream
      screenOk = true
      setScreenGranted(true)
      // When user stops screen share natively, handle gracefully
      screenStream.getVideoTracks()[0].onended = () => {
        setScreenGranted(false)
      }
    } catch {
      // Screen sharing declined — that's OK, mic-only still works
      screenOk = false
    }

    if (micOk) {
      setPermState("granted")
      startListening()
    }
  }, [startListening])

  const pauseResume = useCallback(() => {
    if (isListening) {
      shouldRunRef.current = false
      recognitionRef.current?.stop()
      setIsListening(false)
    } else {
      startListening()
    }
  }, [isListening, startListening])

  useEffect(() => {
    return () => {
      shouldRunRef.current = false
      recognitionRef.current?.stop()
      micStreamRef.current?.getTracks().forEach(t => t.stop())
      screenStreamRef.current?.getTracks().forEach(t => t.stop())
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [])

  const handleCopy = async () => {
    if (!suggestion) return
    await navigator.clipboard.writeText(suggestion).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // ── Permission gate ────────────────────────────────────────────────────────
  if (permState !== "granted") {
    return (
      <Box position="fixed" inset={0} zIndex="modal"
        display="flex" alignItems="center" justifyContent="center"
        css={{ backdropFilter: "blur(16px)", background: "rgba(0,0,0,0.88)" }}
        onClick={e => e.target === e.currentTarget && onClose()}
      >
        <Box maxW="440px" w="92%" p="8"
          css={{
            background: "rgba(4,3,20,0.99)",
            border: "1px solid rgba(192,132,252,0.4)",
            borderRadius: "1.5rem",
            boxShadow: "0 0 60px rgba(192,132,252,0.2)",
          }}
        >
          {permState === "denied" ? (
            <VStack gap="4" textAlign="center">
              <Icon boxSize="10" css={{ color: "#f87171" }}><LuTriangleAlert /></Icon>
              <Heading size="sm" color="white">Permission Denied</Heading>
              <Text fontSize="sm" color="gray.400" lineHeight="tall">
                Click the <Text as="span" color="white" fontWeight="bold">lock icon</Text> in your address bar → Site Settings → allow Microphone. Then try again.
              </Text>
              <HStack gap="3" w="full">
                <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                  css={{ background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.4)", color: "#fca5a5", fontSize: "13px", fontWeight: "700" }}
                  onClick={() => { setPermState("idle"); setError("") }}>
                  Try Again
                </Box>
                <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                  css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#9ca3af", fontSize: "13px", fontWeight: "700" }}
                  onClick={onClose}>
                  Close
                </Box>
              </HStack>
            </VStack>
          ) : (
            <VStack gap="5" textAlign="center">
              <Box w="16" h="16" borderRadius="2xl" display="flex" alignItems="center" justifyContent="center"
                css={{ background: "rgba(192,132,252,0.12)", border: "1px solid rgba(192,132,252,0.5)", boxShadow: "0 0 30px rgba(192,132,252,0.3)" }}>
                <Icon boxSize="7" css={{ color: accentColor }}><LuMonitor /></Icon>
              </Box>
              <VStack gap="2">
                <Heading size="md" color="white">Video Call Intelligence</Heading>
                <Text fontSize="sm" color="gray.400" lineHeight="tall">
                  GALAXIA AI will listen to your video call and whisper tactical suggestions. Two permissions required:
                </Text>
              </VStack>

              {/* Permission checklist */}
              <VStack gap="2" w="full" align="flex-start" p="4" borderRadius="xl"
                css={{ background: "rgba(192,132,252,0.06)", border: "1px solid rgba(192,132,252,0.2)" }}>
                <HStack gap="3">
                  <Box w="5" h="5" borderRadius="full" display="flex" alignItems="center" justifyContent="center"
                    css={{
                      background: micGranted ? "rgba(34,197,94,0.2)" : "rgba(192,132,252,0.15)",
                      border: `1px solid ${micGranted ? "#22c55e" : "rgba(192,132,252,0.4)"}`,
                    }}>
                    <Icon boxSize="3" css={{ color: micGranted ? "#22c55e" : accentColor }}><LuMic /></Icon>
                  </Box>
                  <VStack align="flex-start" gap="0">
                    <Text fontSize="sm" color="white" fontWeight="semibold">Microphone</Text>
                    <Text fontSize="xs" color="gray.500">{micGranted ? "Granted" : "Hears your voice"}</Text>
                  </VStack>
                </HStack>
                <HStack gap="3">
                  <Box w="5" h="5" borderRadius="full" display="flex" alignItems="center" justifyContent="center"
                    css={{
                      background: screenGranted ? "rgba(34,197,94,0.2)" : "rgba(192,132,252,0.15)",
                      border: `1px solid ${screenGranted ? "#22c55e" : "rgba(192,132,252,0.4)"}`,
                    }}>
                    <Icon boxSize="3" css={{ color: screenGranted ? "#22c55e" : accentColor }}><LuMonitor /></Icon>
                  </Box>
                  <VStack align="flex-start" gap="0">
                    <Text fontSize="sm" color="white" fontWeight="semibold">Screen + System Audio <Text as="span" fontSize="xs" color="gray.500">(optional)</Text></Text>
                    <Text fontSize="xs" color="gray.500">{screenGranted ? "Granted" : "Hears the other person too — share your Zoom/Meet tab"}</Text>
                  </VStack>
                </HStack>
              </VStack>

              <VStack gap="1.5" w="full" align="flex-start">
                {["Audio processed live — never recorded", "No uploads, no storage", "Session vanishes on close"].map(item => (
                  <HStack key={item} gap="2">
                    <Icon boxSize="3.5" css={{ color: accentColor }}><LuShieldCheck /></Icon>
                    <Text fontSize="xs" color="gray.400">{item}</Text>
                  </HStack>
                ))}
              </VStack>

              {error && (
                <HStack gap="2" p="3" borderRadius="lg" w="full"
                  css={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.3)" }}>
                  <Icon boxSize="4" css={{ color: "#f87171" }}><LuTriangleAlert /></Icon>
                  <Text fontSize="xs" color="red.300">{error}</Text>
                </HStack>
              )}

              <HStack gap="3" w="full">
                <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                  css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#9ca3af", fontSize: "13px", fontWeight: "700" }}
                  onClick={onClose}>
                  Cancel
                </Box>
                <Box as="button" flex={2} py="2.5" borderRadius="xl" cursor="pointer"
                  display="flex" alignItems="center" justifyContent="center" gap="2"
                  onClick={permState === "idle" ? requestPermissions : undefined}
                  css={{
                    background: permState === "requesting" ? "rgba(192,132,252,0.15)" : "linear-gradient(135deg, #7c3aed, #c084fc)",
                    border: "1px solid rgba(192,132,252,0.6)",
                    color: "white", fontSize: "13px", fontWeight: "800", letterSpacing: "0.06em",
                    boxShadow: "0 0 20px rgba(192,132,252,0.35)",
                    cursor: permState === "requesting" ? "wait" : "pointer",
                  }}>
                  {permState === "requesting" ? (
                    <><Box w="4" h="4" borderRadius="full" css={{ border: "2px solid rgba(192,132,252,0.3)", borderTop: "2px solid #c084fc", animation: "spin 0.8s linear infinite" }} /> Requesting...</>
                  ) : (
                    <><Icon boxSize="4"><LuMonitor /></Icon> GRANT ACCESS</>
                  )}
                </Box>
              </HStack>
            </VStack>
          )}
        </Box>
      </Box>
    )
  }

  // ── Active overlay ─────────────────────────────────────────────────────────
  return (
    <Box
      position="fixed" bottom={0} left={0} right={0} zIndex="modal"
      css={{
        backdropFilter: "blur(24px) saturate(1.5)",
        background: "linear-gradient(to top, rgba(109,40,217,0.20) 0%, rgba(109,40,217,0.08) 100%)",
        borderTop: "2px solid #c084fc",
        boxShadow: "0 -4px 40px rgba(192,132,252,0.4)",
        animation: "slideFromBottom 0.35s cubic-bezier(0.16, 1, 0.3, 1)",
        maxHeight: "36vh",
      }}
    >
      <Box h="1px" css={{ background: "linear-gradient(90deg, transparent, #c084fc, transparent)", boxShadow: "0 0 12px #c084fc" }} />
      <Box p="4" display="flex" flexDirection="column" gap="3" maxH="34vh" overflowY="auto">

        <HStack justify="space-between">
          <HStack gap="2">
            <Box w="6" h="6" borderRadius="full" display="flex" alignItems="center" justifyContent="center"
              css={{ background: "rgba(192,132,252,0.2)", border: "1px solid #c084fc", boxShadow: isListening ? "0 0 12px rgba(192,132,252,0.6)" : "none" }}>
              <Icon boxSize="3" css={{ color: accentColor }}>{isListening ? <LuMic /> : <LuMicOff />}</Icon>
            </Box>
            <HStack gap="1.5">
              <Text fontSize="xs" fontWeight="bold" letterSpacing="widest" textTransform="uppercase" css={{ color: accentColor }}>
                VIDEO CALL AI
              </Text>
              <Box as="span" px="1.5" py="0.5" borderRadius="md"
                css={{
                  background: screenGranted ? "rgba(34,197,94,0.15)" : "rgba(255,255,255,0.07)",
                  border: `1px solid ${screenGranted ? "rgba(34,197,94,0.3)" : "rgba(255,255,255,0.12)"}`,
                  color: screenGranted ? "#86efac" : "#6b7280",
                  fontSize: "9px", fontWeight: "700", letterSpacing: "0.08em",
                }}>
                {screenGranted ? "SCREEN ON" : "MIC ONLY"}
              </Box>
              {isListening && <Box w="4px" h="4px" borderRadius="full" css={{ background: accentColor, animation: "pulse 1s infinite" }} />}
            </HStack>
          </HStack>
          <HStack gap="2">
            <Box as="button" onClick={pauseResume}
              px="2.5" py="1" borderRadius="lg" cursor="pointer"
              display="flex" alignItems="center" gap="1.5"
              css={{
                background: isListening ? "rgba(239,68,68,0.12)" : "rgba(192,132,252,0.12)",
                border: `1px solid ${isListening ? "rgba(239,68,68,0.4)" : "rgba(192,132,252,0.4)"}`,
                color: isListening ? "#f87171" : accentColor,
                fontSize: "11px", fontWeight: "700",
              }}>
              <Icon boxSize="3">{isListening ? <LuMicOff /> : <LuMic />}</Icon>
              {isListening ? "PAUSE" : "RESUME"}
            </Box>
            <Box as="button" onClick={onClose} w="6" h="6" borderRadius="full"
              display="flex" alignItems="center" justifyContent="center" cursor="pointer"
              css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", "&:hover": { background: "rgba(255,255,255,0.1)" } }}>
              <Icon boxSize="3" color="gray.400"><LuX /></Icon>
            </Box>
          </HStack>
        </HStack>

        {!screenGranted && (
          <HStack gap="2" p="2" borderRadius="lg"
            css={{ background: "rgba(192,132,252,0.06)", border: "1px solid rgba(192,132,252,0.2)" }}>
            <Icon boxSize="3.5" css={{ color: "#c084fc80" }}><LuMonitorOff /></Icon>
            <Text fontSize="xs" color="gray.500">
              For full two-way audio, share your Zoom/Meet tab with system audio. Currently hearing mic only.
            </Text>
          </HStack>
        )}

        {(sessionLog.length > 0 || interimText) && (
          <Box p="2.5" borderRadius="lg" css={{ background: "rgba(0,0,0,0.3)", border: "1px solid rgba(192,132,252,0.12)" }}>
            <Text fontSize="xs" color="gray.500" textTransform="uppercase" letterSpacing="wider" mb="1">Hearing</Text>
            <Text fontSize="sm" color="gray.300" lineHeight="tall">
              {sessionLog.slice(-2).join(" ")}
              {interimText && <Box as="span" color="gray.500" fontStyle="italic"> {interimText}</Box>}
            </Text>
          </Box>
        )}

        {error && <HStack gap="2"><Icon boxSize="4" css={{ color: "#f87171" }}><LuCircleAlert /></Icon><Text fontSize="sm" color="red.300">{error}</Text></HStack>}

        {(loading || suggestion) && (
          <Box p="3" borderRadius="xl"
            css={{ background: "rgba(109,40,217,0.12)", border: "1px solid rgba(192,132,252,0.45)", boxShadow: "0 0 20px rgba(192,132,252,0.2)", backdropFilter: "blur(8px)" }}>
            <HStack justify="space-between" mb="1.5">
              <HStack gap="1.5">
                <Box w="2" h="2" borderRadius="full" css={{ background: accentColor, animation: "pulse 1.5s infinite" }} />
                <Text fontSize="xs" fontWeight="bold" letterSpacing="widest" textTransform="uppercase" css={{ color: accentColor }}>
                  {loading ? "ANALYZING..." : "SAY THIS"}
                </Text>
              </HStack>
              {suggestion && !loading && (
                <Box as="button" onClick={handleCopy} display="flex" alignItems="center" gap="1"
                  px="2" py="0.5" borderRadius="md" cursor="pointer"
                  css={{ background: copied ? "rgba(192,132,252,0.2)" : "rgba(255,255,255,0.05)", border: `1px solid ${copied ? accentColor : "rgba(255,255,255,0.1)"}`, color: copied ? accentColor : "#9ca3af", fontSize: "11px", fontWeight: "600" }}>
                  <Icon boxSize="3">{copied ? <LuCheck /> : <LuCopy />}</Icon>
                </Box>
              )}
            </HStack>
            {loading ? (
              <HStack gap="2">{[0,1,2].map(i => (
                <Box key={i} w="5px" h="5px" borderRadius="full" css={{ background: accentColor, animation: `bounce 0.8s ease-in-out ${i*0.15}s infinite` }} />
              ))}</HStack>
            ) : (
              <Text fontSize="md" color="white" fontWeight="semibold" lineHeight="short">{suggestion}</Text>
            )}
          </Box>
        )}

        {isListening && !loading && !suggestion && (
          <HStack gap="1.5" justify="center" opacity={0.5}>
            {[0,1,2,3,4,5].map(i => (
              <Box key={i} w="2.5px" borderRadius="full"
                css={{ background: accentColor, animation: `soundWave 0.7s ease-in-out ${i*0.08}s infinite alternate`, height: `${6+i*3}px` }} />
            ))}
          </HStack>
        )}
      </Box>
    </Box>
  )
}
