import { useState, useRef } from "react"
import { Box, VStack, HStack, Text, Heading, Icon } from "@chakra-ui/react"
import { LuMessageSquare, LuSend, LuCopy, LuCheck, LuX, LuRefreshCw, LuCircleAlert, LuShieldAlert } from "react-icons/lu"
import { askGalaxia } from "@/lib/ai"
import { FALLBACK_RESPONSE } from "@/lib/speech"

const MAX_CHARS = 2000

interface TextAssistantProps {
  onClose: () => void
}

function userFriendlyError(raw: string): string {
  if (raw.includes("rate limit") || raw.includes("429"))
    return "AI servers are busy right now. Please wait a moment and try again."
  if (raw.includes("503") || raw.includes("502") || raw.includes("maintenance"))
    return "Server is under maintenance. Please try again in a moment."
  if (raw.includes("timeout") || raw.includes("network") || raw.includes("fetch"))
    return "Connection issue. Check your internet and try again."
  if (raw.includes("401") || raw.includes("403"))
    return "Authorization error. Please refresh the page."
  return "Server is busy — please try again in a moment."
}

export default function TextAssistant({ onClose }: TextAssistantProps) {
  const [conversation, setConversation] = useState("")
  const [suggestion, setSuggestion] = useState("")
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [retryCount, setRetryCount] = useState(0)
  const [history, setHistory] = useState<Array<{ role: "user" | "assistant"; content: string }>>([])
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const charsLeft = MAX_CHARS - conversation.length
  const isOverLimit = charsLeft < 0
  const isNearLimit = charsLeft <= 200 && charsLeft >= 0

  const analyze = async () => {
    if (!conversation.trim() || isOverLimit) return
    setLoading(true)
    setError("")
    setSuggestion("")

    try {
      const result = await askGalaxia({
        mode: "text",
        userText: `Here is the conversation I need to reply to:\n\n${conversation}\n\nGive me the best tactical reply.`,
        conversationHistory: history,
      })
      const final = result?.trim() || FALLBACK_RESPONSE
      setSuggestion(final)
      setHistory(prev => [
        ...prev,
        { role: "user", content: conversation },
        { role: "assistant", content: final },
      ])
      setRetryCount(0)
    } catch (e: any) {
      const friendly = userFriendlyError(e.message ?? "")
      setError(friendly)
      // Show fallback response so the user isn't left with nothing
      setSuggestion(FALLBACK_RESPONSE)
    } finally {
      setLoading(false)
    }
  }

  const handleCopy = async () => {
    if (!suggestion) return
    try {
      await navigator.clipboard.writeText(suggestion)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Clipboard not available
    }
  }

  const handleRegenerate = () => {
    if (!conversation.trim()) return
    setSuggestion("")
    setRetryCount(c => c + 1)
    analyze()
  }

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value
    // Hard cap at MAX_CHARS — silently truncate to prevent runaway API cost
    if (val.length > MAX_CHARS) {
      setConversation(val.slice(0, MAX_CHARS))
    } else {
      setConversation(val)
    }
  }

  return (
    <Box
      position="fixed"
      inset={0}
      zIndex="modal"
      display="flex"
      alignItems="flex-end"
      justifyContent="center"
      css={{ backdropFilter: "blur(12px)", background: "rgba(0,0,0,0.8)" }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <Box
        w="full"
        maxW="680px"
        mx="auto"
        css={{
          background: "rgba(4,3,20,0.98)",
          border: "1px solid rgba(59,130,246,0.45)",
          borderBottom: "none",
          borderRadius: "1.5rem 1.5rem 0 0",
          boxShadow: "0 -4px 60px rgba(59,130,246,0.25), 0 -1px 0 rgba(59,130,246,0.4)",
          maxHeight: "90vh",
          overflowY: "auto",
        }}
      >
        {/* Header */}
        <Box p="5" css={{ borderBottom: "1px solid rgba(59,130,246,0.2)" }}>
          <HStack justify="space-between">
            <HStack gap="3">
              <Box
                w="9" h="9" borderRadius="xl"
                display="flex" alignItems="center" justifyContent="center"
                css={{
                  background: "rgba(59,130,246,0.15)",
                  border: "1px solid rgba(59,130,246,0.4)",
                  boxShadow: "0 0 14px rgba(59,130,246,0.4)",
                }}
              >
                <Icon boxSize="4" css={{ color: "#60a5fa" }}><LuMessageSquare /></Icon>
              </Box>
              <VStack align="flex-start" gap="0">
                <Heading size="sm" color="white">Text Message Assistant</Heading>
                <Text fontSize="xs" color="gray.400">Paste the conversation — GALAXIA AI crafts your perfect reply</Text>
              </VStack>
            </HStack>
            <Box
              as="button" onClick={onClose}
              w="7" h="7" borderRadius="full"
              display="flex" alignItems="center" justifyContent="center" cursor="pointer"
              css={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                "&:hover": { background: "rgba(255,255,255,0.1)" },
              }}
            >
              <Icon boxSize="3.5" color="gray.400"><LuX /></Icon>
            </Box>
          </HStack>
        </Box>

        <VStack gap="0" p="5" align="stretch">
          {/* Conversation input */}
          <Box mb="4">
            <HStack justify="space-between" mb="2">
              <Text fontSize="xs" color="gray.400" letterSpacing="wider" textTransform="uppercase">
                Paste the conversation
              </Text>
              <Text
                fontSize="xs"
                fontWeight="semibold"
                css={{
                  color: isOverLimit ? "#ef4444" : isNearLimit ? "#f59e0b" : "#4b5563",
                  transition: "color 0.2s",
                }}
              >
                {conversation.length} / {MAX_CHARS}
              </Text>
            </HStack>
            <Box
              as="textarea"
              ref={textareaRef}
              value={conversation}
              onChange={handleChange}
              placeholder={"Paste the full conversation here...\n\nExample:\nThem: Hey, are you free Saturday?\nMe: Maybe, what's up?\nThem: Nothing just wanted to hang"}
              rows={6}
              w="full"
              p="3"
              css={{
                background: isOverLimit ? "rgba(239,68,68,0.06)" : "rgba(255,255,255,0.04)",
                border: `1px solid ${isOverLimit ? "rgba(239,68,68,0.5)" : "rgba(59,130,246,0.25)"}`,
                borderRadius: "0.75rem",
                color: "white",
                fontSize: "0.875rem",
                lineHeight: "1.6",
                resize: "vertical",
                outline: "none",
                fontFamily: "inherit",
                "&::placeholder": { color: "rgba(156,163,175,0.5)" },
                "&:focus": {
                  border: `1px solid ${isOverLimit ? "rgba(239,68,68,0.6)" : "rgba(59,130,246,0.55)"}`,
                  boxShadow: isOverLimit ? "0 0 0 3px rgba(239,68,68,0.1)" : "0 0 0 3px rgba(59,130,246,0.12)",
                },
              }}
              onKeyDown={(e: React.KeyboardEvent<HTMLTextAreaElement>) => {
                if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) analyze()
              }}
            />
            <HStack justify="space-between" mt="1">
              <Text fontSize="xs" color="gray.600">Cmd/Ctrl+Enter to analyze</Text>
              {isOverLimit && (
                <HStack gap="1">
                  <Icon boxSize="3" css={{ color: "#ef4444" }}><LuShieldAlert /></Icon>
                  <Text fontSize="xs" color="red.400" fontWeight="semibold">
                    Exceeds 2,000 character limit
                  </Text>
                </HStack>
              )}
            </HStack>
          </Box>

          {/* Analyze button */}
          <Box
            as="button"
            onClick={analyze}
            disabled={loading || !conversation.trim() || isOverLimit}
            w="full"
            py="3"
            borderRadius="xl"
            display="flex" alignItems="center" justifyContent="center" gap="2"
            cursor={loading || !conversation.trim() || isOverLimit ? "not-allowed" : "pointer"}
            transition="all 0.25s"
            css={{
              background: loading || !conversation.trim() || isOverLimit
                ? "rgba(59,130,246,0.12)"
                : "linear-gradient(135deg, #2563eb, #3b82f6)",
              border: "1px solid rgba(59,130,246,0.5)",
              color: loading || !conversation.trim() || isOverLimit ? "rgba(147,197,253,0.5)" : "white",
              fontWeight: "700",
              fontSize: "0.875rem",
              letterSpacing: "0.05em",
              boxShadow: loading || !conversation.trim() || isOverLimit ? "none" : "0 0 20px rgba(59,130,246,0.5)",
              "&:hover:not(:disabled)": {
                boxShadow: "0 0 30px rgba(59,130,246,0.8)",
                transform: "translateY(-1px)",
              },
            }}
          >
            {loading ? (
              <>
                <Box w="4" h="4" borderRadius="full"
                  css={{ border: "2px solid rgba(147,197,253,0.3)", borderTop: "2px solid #60a5fa", animation: "spin 0.8s linear infinite" }} />
                GALAXIA AI is analyzing...
              </>
            ) : (
              <>
                <Icon boxSize="4"><LuSend /></Icon>
                ANALYZE & GENERATE REPLY
              </>
            )}
          </Box>

          {/* Error banner */}
          {error && (
            <Box mt="4" p="3.5" borderRadius="xl"
              css={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.3)" }}>
              <HStack gap="2.5" mb="1.5">
                <Icon boxSize="4" css={{ color: "#f87171", flexShrink: 0 }}><LuCircleAlert /></Icon>
                <Text fontSize="sm" color="red.300" fontWeight="semibold">{error}</Text>
              </HStack>
              <Box
                as="button"
                onClick={() => { setError(""); setRetryCount(c => c + 1); analyze() }}
                px="3" py="1.5" borderRadius="lg" cursor="pointer"
                display="flex" alignItems="center" gap="1.5"
                css={{
                  background: "rgba(239,68,68,0.15)",
                  border: "1px solid rgba(239,68,68,0.35)",
                  color: "#fca5a5",
                  fontSize: "12px", fontWeight: "700", letterSpacing: "0.05em",
                  "&:hover": { background: "rgba(239,68,68,0.25)" },
                }}
              >
                <Icon boxSize="3"><LuRefreshCw /></Icon>
                TRY AGAIN
              </Box>
            </Box>
          )}

          {/* AI Suggestion (also shown as fallback even on error) */}
          {suggestion && (
            <Box mt="4" p="4" borderRadius="xl"
              css={{
                background: "rgba(59,130,246,0.07)",
                border: "1px solid rgba(59,130,246,0.4)",
                boxShadow: "0 0 20px rgba(59,130,246,0.15)",
              }}
            >
              <HStack justify="space-between" mb="3">
                <HStack gap="2">
                  <Box w="2" h="2" borderRadius="full"
                    css={{ background: "#60a5fa", boxShadow: "0 0 6px #60a5fa", animation: "pulse 2s infinite" }} />
                  <Text fontSize="xs" fontWeight="bold" letterSpacing="widest" textTransform="uppercase"
                    css={{ color: "#60a5fa", textShadow: "0 0 8px #60a5fa80" }}>
                    GALAXIA AI REPLY
                  </Text>
                </HStack>
                <Box
                  as="button" onClick={handleRegenerate}
                  display="flex" alignItems="center" gap="1.5"
                  px="2.5" py="1" borderRadius="lg" cursor="pointer"
                  css={{
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    color: "#9ca3af",
                    fontSize: "11px", fontWeight: "600", letterSpacing: "0.05em",
                    "&:hover": { background: "rgba(255,255,255,0.1)", color: "white" },
                  }}
                >
                  <Icon boxSize="3"><LuRefreshCw /></Icon>
                  REGENERATE
                </Box>
              </HStack>

              <Text fontSize="md" color="white" lineHeight="tall" mb="4">
                {suggestion}
              </Text>

              <Box
                as="button" onClick={handleCopy} w="full" py="2.5" borderRadius="lg"
                display="flex" alignItems="center" justifyContent="center" gap="2"
                cursor="pointer" transition="all 0.2s"
                css={{
                  background: copied ? "rgba(59,130,246,0.3)" : "rgba(59,130,246,0.15)",
                  border: `1px solid ${copied ? "#60a5fa" : "rgba(59,130,246,0.4)"}`,
                  color: copied ? "#93c5fd" : "#60a5fa",
                  fontWeight: "700", fontSize: "0.8rem", letterSpacing: "0.08em",
                  boxShadow: copied ? "0 0 15px rgba(59,130,246,0.5)" : "none",
                  "&:hover": { background: "rgba(59,130,246,0.25)", boxShadow: "0 0 15px rgba(59,130,246,0.4)" },
                }}
              >
                <Icon boxSize="4">{copied ? <LuCheck /> : <LuCopy />}</Icon>
                {copied ? "COPIED TO CLIPBOARD!" : "COPY REPLY"}
              </Box>
            </Box>
          )}
        </VStack>
      </Box>
    </Box>
  )
}
