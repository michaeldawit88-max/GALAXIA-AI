import { useState, useRef, useEffect, useCallback } from "react"
import { Box, HStack, VStack, Text, Icon, Heading } from "@chakra-ui/react"
import {
  LuBluetooth, LuMic, LuMicOff, LuX, LuCircleAlert, LuVolume2,
  LuShieldCheck, LuTriangleAlert,
} from "react-icons/lu"
import { askGalaxia } from "@/lib/ai"
import { speakText, FALLBACK_RESPONSE } from "@/lib/speech"

function friendlyError(raw: string): string {
  if (raw.includes("rate limit") || raw.includes("429")) return "Server busy — try again shortly."
  if (raw.includes("50") || raw.includes("maintenance")) return "Server busy, please try again in a moment."
  if (raw.includes("network") || raw.includes("fetch")) return "Connection issue."
  if (raw.includes("not-allowed") || raw.includes("Permission")) return "Microphone blocked. Allow it in browser settings."
  return "Server busy, please try again in a moment."
}

type PermState = "idle" | "requesting" | "granted" | "denied"

interface FaceToFaceAssistantProps {
  onClose: () => void
}

export default function FaceToFaceAssistant({ onClose }: FaceToFaceAssistantProps) {
  const [permState, setPermState] = useState<PermState>("idle")
  const [isListening, setIsListening] = useState(false)
  const [interimText, setInterimText] = useState("")
  const [whisperLog, setWhisperLog] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const [error, setError] = useState("")

  const streamRef = useRef<MediaStream | null>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const sessionLogRef = useRef<string[]>([])
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const speakingRef = useRef(false)
  const shouldRunRef = useRef(false)
  const historyRef = useRef<Array<{ role: "user" | "assistant"; content: string }>>([])

  const accentColor = "#2dd4bf"

  const queryAI = useCallback(async (line: string) => {
    if (speakingRef.current) return
    setLoading(true)
    setError("")
    try {
      const result = await askGalaxia({
        mode: "facetoface",
        userText: `Face-to-face — just heard:\n"${line}"\n\nContext:\n${sessionLogRef.current.slice(-3).join("\n")}\n\nWhisper (under 12 words, speak immediately):`,
        conversationHistory: historyRef.current,
      })
      const whisper = result?.trim() || FALLBACK_RESPONSE
      setWhisperLog(prev => [...prev.slice(-4), whisper])
      historyRef.current = [
        ...historyRef.current,
        { role: "user", content: line },
        { role: "assistant", content: whisper },
      ].slice(-12)

      speakingRef.current = true
      setSpeaking(true)
      speakText(whisper, 1.0, 1.05)
      const checkDone = setInterval(() => {
        if (!window.speechSynthesis.speaking) {
          clearInterval(checkDone)
          speakingRef.current = false
          setSpeaking(false)
        }
      }, 200)
    } catch (e: any) {
      setError(friendlyError(e.message ?? ""))
      setWhisperLog(prev => [...prev.slice(-4), FALLBACK_RESPONSE])
    } finally {
      setLoading(false)
    }
  }, [])

  const buildRecognition = useCallback(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SR) return null
    const rec = new SR() as SpeechRecognition
    rec.continuous = true
    rec.interimResults = true
    rec.lang = "en-US"

    rec.onresult = (e: SpeechRecognitionEvent) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript
        if (e.results[i].isFinal) {
          setInterimText("")
          const line = t.trim()
          if (!line) continue
          sessionLogRef.current = [...sessionLogRef.current, line].slice(-8)
          if (debounceRef.current) clearTimeout(debounceRef.current)
          debounceRef.current = setTimeout(() => queryAI(line), 600)
        } else {
          setInterimText(t)
        }
      }
    }
    rec.onerror = (e: SpeechRecognitionErrorEvent) => {
      if (e.error === "not-allowed") { shouldRunRef.current = false; setIsListening(false); setPermState("denied") }
    }
    rec.onend = () => {
      setIsListening(false)
      if (shouldRunRef.current) {
        setTimeout(() => {
          if (!shouldRunRef.current) return
          try { const r2 = buildRecognition(); if (!r2) return; recognitionRef.current = r2; r2.start(); setIsListening(true) } catch {}
        }, 50)
      }
    }
    return rec
  }, [queryAI])

  const requestPermission = useCallback(async () => {
    setPermState("requesting")
    setError("")
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false })
      streamRef.current = stream
      setPermState("granted")

      const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      if (!SR) { setError("Speech recognition requires Chrome or Edge."); return }

      shouldRunRef.current = true
      const rec = buildRecognition()
      if (!rec) return
      recognitionRef.current = rec
      rec.start()
      setIsListening(true)

      // Boop: mic live
      try {
        const ctx = new AudioContext()
        const o = ctx.createOscillator(), g = ctx.createGain()
        o.connect(g); g.connect(ctx.destination)
        o.frequency.setValueAtTime(880, ctx.currentTime)
        o.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.08)
        g.gain.setValueAtTime(0.18, ctx.currentTime)
        g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18)
        o.start(); o.stop(ctx.currentTime + 0.18)
        o.onended = () => ctx.close()
      } catch {}
    } catch (e: any) {
      if (e.name === "NotAllowedError") {
        setPermState("denied")
        setError("Microphone access denied.")
      } else {
        setPermState("idle")
        setError(`Could not access microphone: ${e.message}`)
      }
    }
  }, [buildRecognition])

  const pauseResume = useCallback(() => {
    if (isListening) {
      shouldRunRef.current = false
      recognitionRef.current?.stop()
      setIsListening(false)
    } else {
      shouldRunRef.current = true
      const rec = buildRecognition()
      if (!rec) return
      recognitionRef.current = rec
      rec.start()
      setIsListening(true)
    }
  }, [isListening, buildRecognition])

  useEffect(() => {
    return () => {
      shouldRunRef.current = false
      recognitionRef.current?.stop()
      streamRef.current?.getTracks().forEach(t => t.stop())
      window.speechSynthesis?.cancel()
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [])

  // ── Permission gate ────────────────────────────────────────────────────────
  if (permState !== "granted") {
    return (
      <Box position="fixed" inset={0} zIndex="modal"
        display="flex" alignItems="center" justifyContent="center"
        css={{ backdropFilter: "blur(16px)", background: "rgba(0,0,0,0.88)" }}
        onClick={e => e.target === e.currentTarget && onClose()}
      >
        <Box maxW="390px" w="92%" p="8"
          css={{
            background: "rgba(4,3,20,0.99)",
            border: "1px solid rgba(45,212,191,0.4)",
            borderRadius: "1.5rem",
            boxShadow: "0 0 60px rgba(45,212,191,0.2)",
          }}
        >
          {permState === "denied" ? (
            <VStack gap="4" textAlign="center">
              <Icon boxSize="10" css={{ color: "#f87171" }}><LuTriangleAlert /></Icon>
              <Heading size="sm" color="white">Microphone Blocked</Heading>
              <Text fontSize="sm" color="gray.400" lineHeight="tall">
                Click the <Text as="span" color="white" fontWeight="bold">lock icon</Text> in your address bar → Site Settings → allow Microphone.
              </Text>
              <HStack gap="3" w="full">
                <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                  css={{ background: "rgba(45,212,191,0.15)", border: "1px solid rgba(45,212,191,0.4)", color: "#5eead4", fontSize: "13px", fontWeight: "700" }}
                  onClick={() => { setPermState("idle"); setError("") }}>
                  Try Again
                </Box>
                <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                  css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#9ca3af", fontSize: "13px", fontWeight: "700" }}
                  onClick={onClose}>
                  Close
                </Box>
              </HStack>
            </VStack>
          ) : (
            <VStack gap="5" textAlign="center">
              <Box w="16" h="16" borderRadius="2xl" display="flex" alignItems="center" justifyContent="center"
                css={{ background: "rgba(45,212,191,0.12)", border: "1px solid rgba(45,212,191,0.5)", boxShadow: "0 0 30px rgba(45,212,191,0.3)" }}>
                <Icon boxSize="7" css={{ color: accentColor }}><LuBluetooth /></Icon>
              </Box>
              <VStack gap="2">
                <Heading size="md" color="white">Earpiece Mode</Heading>
                <Text fontSize="sm" color="gray.400" lineHeight="tall">
                  GALAXIA AI listens to the room and whispers tactical responses through your earpiece in under a second. <Text as="span" color={accentColor} fontWeight="semibold">Zero data is stored.</Text>
                </Text>
              </VStack>
              <VStack gap="2" w="full" align="flex-start" p="3.5" borderRadius="xl"
                css={{ background: "rgba(45,212,191,0.06)", border: "1px solid rgba(45,212,191,0.2)" }}>
                {["High-pitched boop = mic is live", "AI response spoken to earpiece instantly", "Nothing saved — session vanishes on close"].map(item => (
                  <HStack key={item} gap="2">
                    <Icon boxSize="3.5" css={{ color: accentColor }}><LuShieldCheck /></Icon>
                    <Text fontSize="xs" color="gray.300">{item}</Text>
                  </HStack>
                ))}
              </VStack>
              {error && (
                <HStack gap="2" p="3" borderRadius="lg" w="full"
                  css={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.3)" }}>
                  <Icon boxSize="4" css={{ color: "#f87171" }}><LuTriangleAlert /></Icon>
                  <Text fontSize="xs" color="red.300">{error}</Text>
                </HStack>
              )}
              <HStack gap="3" w="full">
                <Box as="button" flex={1} py="2.5" borderRadius="xl" cursor="pointer"
                  css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#9ca3af", fontSize: "13px", fontWeight: "700" }}
                  onClick={onClose}>
                  Cancel
                </Box>
                <Box as="button" flex={2} py="2.5" borderRadius="xl" cursor="pointer"
                  display="flex" alignItems="center" justifyContent="center" gap="2"
                  onClick={permState === "idle" ? requestPermission : undefined}
                  css={{
                    background: permState === "requesting" ? "rgba(45,212,191,0.15)" : "linear-gradient(135deg, #0d9488, #2dd4bf)",
                    border: "1px solid rgba(45,212,191,0.6)",
                    color: "white", fontSize: "13px", fontWeight: "800", letterSpacing: "0.06em",
                    boxShadow: "0 0 20px rgba(45,212,191,0.35)",
                    cursor: permState === "requesting" ? "wait" : "pointer",
                  }}>
                  {permState === "requesting" ? (
                    <><Box w="4" h="4" borderRadius="full" css={{ border: "2px solid rgba(45,212,191,0.3)", borderTop: "2px solid #2dd4bf", animation: "spin 0.8s linear infinite" }} /> Requesting...</>
                  ) : (
                    <><Icon boxSize="4"><LuMic /></Icon> ALLOW &amp; ACTIVATE</>
                  )}
                </Box>
              </HStack>
            </VStack>
          )}
        </Box>
      </Box>
    )
  }

  // ── Active earpiece overlay ────────────────────────────────────────────────
  return (
    <Box
      position="fixed" bottom={0} left={0} right={0} zIndex="modal"
      css={{
        backdropFilter: "blur(24px) saturate(1.5)",
        background: "linear-gradient(to top, rgba(13,148,136,0.18) 0%, rgba(13,148,136,0.08) 100%)",
        borderTop: "2px solid #2dd4bf",
        boxShadow: "0 -4px 40px rgba(45,212,191,0.4)",
        animation: "slideFromBottom 0.35s cubic-bezier(0.16, 1, 0.3, 1)",
        maxHeight: "32vh",
      }}
    >
      <Box h="1px" css={{ background: "linear-gradient(90deg, transparent, #2dd4bf, transparent)", boxShadow: "0 0 12px #2dd4bf" }} />
      <Box p="4" display="flex" flexDirection="column" gap="3">

        <HStack justify="space-between">
          <HStack gap="2">
            <Box w="7" h="7" borderRadius="full" display="flex" alignItems="center" justifyContent="center"
              css={{
                background: speaking ? "rgba(45,212,191,0.35)" : "rgba(45,212,191,0.18)",
                border: "1px solid #2dd4bf",
                boxShadow: speaking ? "0 0 20px rgba(45,212,191,0.8)" : "0 0 10px rgba(45,212,191,0.4)",
                animation: speaking ? "pulse 0.6s ease-in-out infinite" : "none",
              }}>
              <Icon boxSize="3.5" css={{ color: accentColor }}>
                {speaking ? <LuVolume2 /> : isListening ? <LuMic /> : <LuMicOff />}
              </Icon>
            </Box>
            <VStack align="flex-start" gap="0">
              <HStack gap="1.5">
                <Text fontSize="xs" fontWeight="bold" letterSpacing="widest" textTransform="uppercase"
                  css={{ color: accentColor, textShadow: "0 0 8px #2dd4bf80" }}>
                  EARPIECE AI
                </Text>
                <Icon boxSize="3" css={{ color: accentColor }}><LuBluetooth /></Icon>
                {isListening && <Box w="4px" h="4px" borderRadius="full" css={{ background: accentColor, animation: "pulse 1s infinite" }} />}
              </HStack>
              <Text fontSize="xs" color="gray.500" letterSpacing="wide" textTransform="uppercase">
                {speaking ? "WHISPERING NOW..." : loading ? "PROCESSING..." : isListening ? "LISTENING TO ROOM" : "PAUSED"}
              </Text>
            </VStack>
          </HStack>
          <HStack gap="2">
            <Box as="button" onClick={pauseResume}
              px="2.5" py="1" borderRadius="lg" cursor="pointer"
              display="flex" alignItems="center" gap="1.5"
              css={{
                background: isListening ? "rgba(239,68,68,0.12)" : "rgba(45,212,191,0.12)",
                border: `1px solid ${isListening ? "rgba(239,68,68,0.4)" : "rgba(45,212,191,0.4)"}`,
                color: isListening ? "#f87171" : accentColor,
                fontSize: "11px", fontWeight: "700",
              }}>
              <Icon boxSize="3">{isListening ? <LuMicOff /> : <LuMic />}</Icon>
              {isListening ? "PAUSE" : "RESUME"}
            </Box>
            <Box as="button" onClick={onClose} w="6" h="6" borderRadius="full"
              display="flex" alignItems="center" justifyContent="center" cursor="pointer"
              css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", "&:hover": { background: "rgba(255,255,255,0.1)" } }}>
              <Icon boxSize="3" color="gray.400"><LuX /></Icon>
            </Box>
          </HStack>
        </HStack>

        {error && <HStack gap="2"><Icon boxSize="4" css={{ color: "#f87171" }}><LuCircleAlert /></Icon><Text fontSize="sm" color="red.300">{error}</Text></HStack>}
        {interimText && <Text fontSize="xs" color="gray.500" fontStyle="italic">Hearing: "{interimText}"</Text>}

        {whisperLog.length > 0 && (
          <Box p="3" borderRadius="xl"
            css={{
              background: "rgba(13,148,136,0.10)",
              border: "1px solid rgba(45,212,191,0.4)",
              boxShadow: speaking ? "0 0 20px rgba(45,212,191,0.4)" : "0 0 8px rgba(45,212,191,0.12)",
            }}>
            <HStack gap="2" mb="1.5">
              <Icon boxSize="3" css={{ color: accentColor }}><LuBluetooth /></Icon>
              <Text fontSize="xs" fontWeight="bold" letterSpacing="widest" textTransform="uppercase" css={{ color: accentColor }}>
                {speaking ? "WHISPERING NOW" : "LAST WHISPER"}
              </Text>
            </HStack>
            {loading && whisperLog.length === 0 ? (
              <HStack gap="2">{[0,1,2].map(i => (
                <Box key={i} w="5px" h="5px" borderRadius="full"
                  css={{ background: accentColor, animation: `bounce 0.8s ease-in-out ${i*0.15}s infinite` }} />
              ))}</HStack>
            ) : (
              <Text fontSize="md" color="white" fontWeight="semibold" fontStyle="italic">
                "{whisperLog[whisperLog.length - 1]}"
              </Text>
            )}
          </Box>
        )}

        {isListening && !loading && whisperLog.length === 0 && (
          <HStack gap="1.5" justify="center" opacity={0.4}>
            {[0,1,2,3,4,5,6].map(i => (
              <Box key={i} w="2px" borderRadius="full"
                css={{ background: accentColor, animation: `soundWave 0.6s ease-in-out ${i*0.07}s infinite alternate`, height: `${5+i*3}px` }} />
            ))}
          </HStack>
        )}
      </Box>
    </Box>
  )
}
