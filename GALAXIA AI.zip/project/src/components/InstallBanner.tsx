import { useState, useEffect } from "react"
import { Box, HStack, VStack, Text, Icon, Heading } from "@chakra-ui/react"
import {
  LuDownload, LuX, LuSmartphone, LuBell, LuMic, LuShare2,
  LuChevronRight, LuCircleCheck,
} from "react-icons/lu"

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>
}

export function useInstallPrompt() {
  const [prompt, setPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [installed, setInstalled] = useState(false)

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault()
      setPrompt(e as BeforeInstallPromptEvent)
    }
    window.addEventListener("beforeinstallprompt", handler)
    window.addEventListener("appinstalled", () => setInstalled(true))
    // Check if already installed (standalone mode)
    if (window.matchMedia("(display-mode: standalone)").matches) setInstalled(true)
    return () => window.removeEventListener("beforeinstallprompt", handler)
  }, [])

  const install = async () => {
    if (!prompt) return false
    await prompt.prompt()
    const { outcome } = await prompt.userChoice
    if (outcome === "accepted") {
      setInstalled(true)
      setPrompt(null)
    }
    return outcome === "accepted"
  }

  return { prompt, installed, install }
}

interface InstallBannerProps {
  prompt: BeforeInstallPromptEvent | null
  installed: boolean
  install: () => Promise<boolean>
}

export function InstallBanner({ prompt, installed, install }: InstallBannerProps) {
  const [dismissed, setDismissed] = useState(
    () => localStorage.getItem("galaxia_install_dismissed") === "true"
  )
  const [showInstructions, setShowInstructions] = useState(false)

  const dismiss = () => {
    setDismissed(true)
    localStorage.setItem("galaxia_install_dismissed", "true")
  }

  // Show banner if: prompt available (Android/desktop) OR iOS (no prompt but not installed and not dismissed)
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent)
  const isInStandalone = window.matchMedia("(display-mode: standalone)").matches
  const showBanner = !installed && !isInStandalone && !dismissed && (!!prompt || isIOS)

  if (!showBanner) return null

  return (
    <>
      <Box
        position="fixed" bottom="0" left="0" right="0" zIndex={1600}
        css={{
          background: "linear-gradient(135deg, rgba(4,3,20,0.97) 0%, rgba(10,5,30,0.97) 100%)",
          borderTop: "1px solid rgba(99,102,241,0.5)",
          boxShadow: "0 -4px 40px rgba(99,102,241,0.3)",
          backdropFilter: "blur(20px)",
          animation: "slideFromBottom 0.5s cubic-bezier(0.16, 1, 0.3, 1)",
        }}
        p="4"
      >
        <HStack justify="space-between" align="flex-start" gap="3">
          <HStack gap="3" align="center">
            <Box
              w="10" h="10" borderRadius="xl" flexShrink={0}
              overflow="hidden"
              css={{ border: "1px solid rgba(99,102,241,0.5)", boxShadow: "0 0 16px rgba(99,102,241,0.4)" }}
            >
              <img src="/icons/icon-192.webp" alt="GALAXIA AI" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            </Box>
            <VStack align="flex-start" gap="0">
              <Text fontSize="sm" fontWeight="bold" color="white">Install GALAXIA AI</Text>
              <Text fontSize="xs" color="gray.400">Add to home screen for full access</Text>
            </VStack>
          </HStack>
          <HStack gap="2">
            {prompt && (
              <Box as="button" onClick={install}
                px="4" py="2" borderRadius="xl" cursor="pointer"
                display="flex" alignItems="center" gap="1.5"
                css={{
                  background: "linear-gradient(135deg, #4f46e5, #6366f1)",
                  border: "1px solid rgba(99,102,241,0.6)",
                  color: "white", fontSize: "13px", fontWeight: "800", letterSpacing: "0.05em",
                  boxShadow: "0 0 20px rgba(99,102,241,0.5)",
                  "&:hover": { boxShadow: "0 0 30px rgba(99,102,241,0.8)", transform: "translateY(-1px)" },
                  transition: "all 0.2s",
                }}>
                <Icon boxSize="3.5"><LuDownload /></Icon>
                INSTALL
              </Box>
            )}
            {isIOS && !prompt && (
              <Box as="button" onClick={() => setShowInstructions(true)}
                px="4" py="2" borderRadius="xl" cursor="pointer"
                display="flex" alignItems="center" gap="1.5"
                css={{
                  background: "linear-gradient(135deg, #4f46e5, #6366f1)",
                  border: "1px solid rgba(99,102,241,0.6)",
                  color: "white", fontSize: "13px", fontWeight: "800",
                  boxShadow: "0 0 20px rgba(99,102,241,0.5)",
                }}>
                <Icon boxSize="3.5"><LuShare2 /></Icon>
                HOW TO INSTALL
              </Box>
            )}
            <Box as="button" onClick={dismiss}
              w="7" h="7" borderRadius="full" cursor="pointer"
              display="flex" alignItems="center" justifyContent="center"
              css={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)", "&:hover": { background: "rgba(255,255,255,0.12)" } }}>
              <Icon boxSize="3" color="gray.400"><LuX /></Icon>
            </Box>
          </HStack>
        </HStack>
      </Box>

      {showInstructions && (
        <InstallInstructionsModal onClose={() => setShowInstructions(false)} />
      )}
    </>
  )
}

function InstallInstructionsModal({ onClose }: { onClose: () => void }) {
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent)
  const isAndroid = /android/i.test(navigator.userAgent)

  const iosSteps = [
    { icon: <LuShare2 />, text: 'Tap the Share button at the bottom of Safari (the box with an arrow pointing up)' },
    { icon: <LuSmartphone />, text: 'Scroll down and tap "Add to Home Screen"' },
    { icon: <LuCircleCheck />, text: 'Tap "Add" — GALAXIA AI appears on your home screen like a native app' },
  ]

  const androidSteps = [
    { icon: <LuChevronRight />, text: 'Tap the 3-dot menu (⋮) in Chrome, top right' },
    { icon: <LuSmartphone />, text: 'Tap "Add to Home screen" or "Install app"' },
    { icon: <LuCircleCheck />, text: 'Tap "Install" — GALAXIA AI installs on your home screen' },
  ]

  const steps = isIOS ? iosSteps : isAndroid ? androidSteps : iosSteps

  const capabilities = [
    { icon: <LuMic />, label: "Live microphone access for phone/video calls" },
    { icon: <LuBell />, label: "Push notifications for real-time tactical alerts" },
    { icon: <LuSmartphone />, label: "Full-screen app — no browser bars" },
    { icon: <LuDownload />, label: "Works faster, offline-ready" },
  ]

  return (
    <Box position="fixed" inset={0} zIndex={1700}
      display="flex" alignItems="center" justifyContent="center"
      css={{ backdropFilter: "blur(16px)", background: "rgba(0,0,0,0.85)" }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <Box maxW="420px" w="92%"
        css={{
          background: "rgba(4,3,20,0.99)",
          border: "1px solid rgba(99,102,241,0.4)",
          borderRadius: "1.5rem",
          boxShadow: "0 0 60px rgba(99,102,241,0.25)",
          maxHeight: "90vh",
          overflowY: "auto",
        }}
      >
        {/* Header */}
        <Box p="5" css={{ borderBottom: "1px solid rgba(99,102,241,0.2)" }}>
          <HStack justify="space-between">
            <HStack gap="3">
              <Box w="10" h="10" borderRadius="xl" overflow="hidden"
                css={{ border: "1px solid rgba(99,102,241,0.4)", boxShadow: "0 0 14px rgba(99,102,241,0.3)" }}>
                <img src="/icons/icon-192.webp" alt="GALAXIA AI" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </Box>
              <VStack align="flex-start" gap="0">
                <Heading size="sm" color="white">Install GALAXIA AI</Heading>
                <Text fontSize="xs" color="gray.400">Free · No App Store needed</Text>
              </VStack>
            </HStack>
            <Box as="button" onClick={onClose} w="7" h="7" borderRadius="full"
              display="flex" alignItems="center" justifyContent="center" cursor="pointer"
              css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>
              <Icon boxSize="3.5" color="gray.400"><LuX /></Icon>
            </Box>
          </HStack>
        </Box>

        <VStack gap="5" p="5" align="stretch">
          {/* What you unlock */}
          <Box p="4" borderRadius="xl"
            css={{ background: "rgba(99,102,241,0.07)", border: "1px solid rgba(99,102,241,0.25)" }}>
            <Text fontSize="xs" fontWeight="bold" letterSpacing="wider" textTransform="uppercase" mb="3"
              css={{ color: "#818cf8" }}>
              What you unlock by installing
            </Text>
            <VStack gap="2.5" align="flex-start">
              {capabilities.map((c, i) => (
                <HStack key={i} gap="3">
                  <Box w="7" h="7" borderRadius="lg" flexShrink={0}
                    display="flex" alignItems="center" justifyContent="center"
                    css={{ background: "rgba(99,102,241,0.2)", border: "1px solid rgba(99,102,241,0.35)" }}>
                    <Icon boxSize="3.5" css={{ color: "#818cf8" }}>{c.icon}</Icon>
                  </Box>
                  <Text fontSize="sm" color="gray.300">{c.label}</Text>
                </HStack>
              ))}
            </VStack>
          </Box>

          {/* Install steps */}
          <VStack gap="0" align="stretch">
            <Text fontSize="xs" fontWeight="bold" letterSpacing="wider" textTransform="uppercase" mb="3"
              css={{ color: "#6366f1" }}>
              {isIOS ? "Install on iPhone / iPad (Safari)" : isAndroid ? "Install on Android (Chrome)" : "How to install"}
            </Text>
            {steps.map((step, i) => (
              <HStack key={i} gap="3" align="flex-start" mb={i < steps.length - 1 ? "4" : "0"}>
                <VStack gap="0" align="center">
                  <Box w="7" h="7" borderRadius="full"
                    display="flex" alignItems="center" justifyContent="center"
                    css={{ background: "linear-gradient(135deg, #4f46e5, #6366f1)", boxShadow: "0 0 12px rgba(99,102,241,0.5)", flexShrink: 0 }}>
                    <Text fontSize="xs" fontWeight="black" color="white">{i + 1}</Text>
                  </Box>
                  {i < steps.length - 1 && <Box w="1px" h="8" css={{ background: "rgba(99,102,241,0.3)" }} />}
                </VStack>
                <Box pt="0.5">
                  <Text fontSize="sm" color="gray.300" lineHeight="tall">{step.text}</Text>
                </Box>
              </HStack>
            ))}
          </VStack>

          {/* Note */}
          <Box p="3" borderRadius="lg"
            css={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <Text fontSize="xs" color="gray.500" lineHeight="tall">
              GALAXIA AI is a Progressive Web App (PWA) — no App Store required. It installs directly from your browser, takes seconds, and gives you full mic and notification access just like a native app. All processing is live — no data saved.
            </Text>
          </Box>

          <Box as="button" onClick={onClose} w="full" py="3" borderRadius="xl" cursor="pointer"
            css={{
              background: "linear-gradient(135deg, #4f46e5, #6366f1)",
              color: "white", fontWeight: "800", fontSize: "0.875rem", letterSpacing: "0.05em",
              boxShadow: "0 0 20px rgba(99,102,241,0.4)",
            }}>
            GOT IT — INSTALL NOW
          </Box>
        </VStack>
      </Box>
    </Box>
  )
}
