import { Box, VStack, HStack, Text, Heading, Badge, Icon } from "@chakra-ui/react"
import type { AssistantConfig } from "@/App"

interface FeatureCardProps {
  assistant: AssistantConfig
  isActive: boolean
  onClick: () => void
}

export default function FeatureCard({ assistant, isActive, onClick }: FeatureCardProps) {
  const { accentHex, borderHex, bgHex, glowAnim } = assistant

  const cardBorder = isActive ? borderHex : `${accentHex}45`
  const cardBg = isActive ? bgHex : `${accentHex}0a`
  const cardShadow = isActive
    ? `0 0 28px ${accentHex}60, 0 0 80px ${accentHex}28, inset 0 0 50px ${accentHex}0a`
    : `0 0 18px ${accentHex}28, 0 0 40px ${accentHex}10, 0 4px 30px rgba(0,0,0,0.4)`

  return (
    <Box
      as="button"
      onClick={onClick}
      textAlign="left"
      w="full"
      position="relative"
      p={{ base: "5", md: "7" }}
      cursor="pointer"
      transition="all 0.35s ease"
      css={{
        borderRadius: "1.25rem",
        border: `1px solid ${cardBorder}`,
        background: cardBg,
        boxShadow: cardShadow,
        backdropFilter: "blur(14px)",
        "&:hover": {
          border: `1px solid ${borderHex}`,
          background: `${accentHex}12`,
          boxShadow: `0 0 40px ${accentHex}70, 0 0 100px ${accentHex}30`,
          transform: "translateY(-3px)",
        },
      }}
    >
      {/* Active pulsing dot indicator */}
      {isActive && (
        <Box
          position="absolute"
          top="18px"
          right="18px"
          w="10px"
          h="10px"
          borderRadius="full"
          css={{
            background: accentHex,
            boxShadow: `0 0 10px 3px ${accentHex}90, 0 0 22px 8px ${accentHex}40`,
            animation: "pulse 1.5s ease-in-out infinite",
          }}
        />
      )}

      <VStack align="flex-start" gap="4">
        {/* Icon box */}
        <Box
          w="12"
          h="12"
          borderRadius="xl"
          display="flex"
          alignItems="center"
          justifyContent="center"
          css={{
            background: isActive ? `${accentHex}22` : "rgba(255,255,255,0.04)",
            border: `1px solid ${isActive ? borderHex : "rgba(255,255,255,0.07)"}`,
            boxShadow: isActive ? `0 0 18px ${accentHex}50` : "none",
          }}
        >
          <Icon
            boxSize="5"
            css={{
              color: isActive ? accentHex : "#9ca3af",
              filter: isActive ? `drop-shadow(0 0 6px ${accentHex})` : "none",
            }}
          >
            {assistant.iconElement}
          </Icon>
        </Box>

        {/* Title + badge */}
        <Box w="full">
          <HStack gap="2" align="center" mb="2" flexWrap="wrap">
            <Heading
              size="sm"
              fontWeight="bold"
              letterSpacing="tight"
              css={{
                color: accentHex,
                textShadow: isActive
                  ? `0 0 8px ${accentHex}, 0 0 20px ${accentHex}, 0 0 40px ${accentHex}80`
                  : `0 0 6px ${accentHex}90, 0 0 16px ${accentHex}60`,
                animation: `${glowAnim} 2.5s ease-in-out infinite alternate`,
              }}
            >
              {assistant.title}
            </Heading>
            {isActive && (
              <Badge
                fontSize="2xs"
                px="2"
                py="0.5"
                letterSpacing="wider"
                textTransform="uppercase"
                css={{
                  background: `${accentHex}22`,
                  color: accentHex,
                  border: `1px solid ${accentHex}60`,
                  borderRadius: "9999px",
                }}
              >
                ACTIVE
              </Badge>
            )}
          </HStack>
          <Text fontSize="sm" color="gray.400" lineHeight="tall">
            {assistant.description}
          </Text>
        </Box>

        {/* Status bar */}
        <HStack gap="2" css={{ opacity: isActive ? 1 : 0.45 }}>
          <Box
            w="7px"
            h="7px"
            borderRadius="full"
            css={{
              background: isActive ? accentHex : "#4b5563",
              boxShadow: isActive ? `0 0 8px ${accentHex}` : "none",
              animation: isActive ? "pulse 2s ease-in-out infinite" : "none",
            }}
          />
          <Text
            fontSize="xs"
            letterSpacing="wide"
            fontWeight="medium"
            css={{
              color: isActive ? accentHex : "#6b7280",
              textShadow: isActive ? `0 0 8px ${accentHex}80` : "none",
            }}
          >
            {isActive ? "LISTENING · TAP TO DEACTIVATE" : "TAP TO ACTIVATE"}
          </Text>
        </HStack>
      </VStack>
    </Box>
  )
}
