import { Box, Heading } from "@chakra-ui/react"

export default function GlaxiaLogo() {
  return (
    <Box>
      <Heading
        fontSize={{ base: "4xl", md: "6xl", lg: "7xl" }}
        fontWeight="black"
        letterSpacing="widest"
        textTransform="uppercase"
        lineHeight="1"
        css={{
          background: "linear-gradient(135deg, #60a5fa 0%, #38bdf8 25%, #a78bfa 55%, #22d3ee 80%, #60a5fa 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
          backgroundSize: "200% 200%",
          animation: "galaxiaPulse 4s ease-in-out infinite alternate",
        }}
      >
        GALAXIA
      </Heading>
      {/* Steady glow underline */}
      <Box
        h="2px"
        mt="2"
        css={{
          background: "linear-gradient(90deg, transparent 0%, #60a5fa 20%, #38bdf8 50%, #a78bfa 80%, transparent 100%)",
          boxShadow: "0 0 8px #60a5fa, 0 0 18px #38bdf8, 0 0 35px #a78bfa60",
          borderRadius: "9999px",
        }}
      />
    </Box>
  )
}
