import { useState, useCallback } from "react"
import { Box, VStack, HStack, Text, Icon, Heading } from "@chakra-ui/react"
import {
  LuBell, LuX, LuSend, LuCopy, LuCheck, LuShieldCheck,
  LuRefreshCw, LuTriangleAlert, LuBellOff, LuBellRing,
} from "react-icons/lu"
import { askGalaxia } from "@/lib/ai"
import { FALLBACK_RESPONSE } from "@/lib/speech"

const MAX_CHARS = 2000

function friendlyError(raw: string): string {
  if (raw.includes("rate limit") || raw.includes("429")) return "Server busy — please try again in a moment."
  if (raw.includes("50") || raw.includes("maintenance")) return "Server is busy, please try again in a moment."
  if (raw.includes("network") || raw.includes("fetch")) return "Connection issue. Check your internet."
  return "Server is busy, please try again in a moment."
}

// App badges for visual context — purely cosmetic labels the user selects
const APP_SOURCES = [
  { id: "imessage", label: "iMessage", color: "#34d399" },
  { id: "whatsapp", label: "WhatsApp", color: "#4ade80" },
  { id: "instagram", label: "Instagram", color: "#c084fc" },
  { id: "tinder", label: "Tinder", color: "#fb923c" },
  { id: "email", label: "Email", color: "#60a5fa" },
  { id: "linkedin", label: "LinkedIn", color: "#38bdf8" },
  { id: "slack", label: "Slack", color: "#f472b6" },
  { id: "other", label: "Other", color: "#94a3b8" },
]

interface NotificationReaderProps {
  onClose: () => void
}

export default function NotificationReader({ onClose }: NotificationReaderProps) {
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(
    "Notification" in window ? Notification.permission : "denied"
  )
  const [selectedApp, setSelectedApp] = useState("imessage")
  const [notifText, setNotifText] = useState("")
  const [context, setContext] = useState("")
  const [suggestion, setSuggestion] = useState("")
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [history, setHistory] = useState<Array<{ role: "user" | "assistant"; content: string }>>([])

  const charsLeft = MAX_CHARS - notifText.length
  const isOverLimit = charsLeft < 0
  const app = APP_SOURCES.find(a => a.id === selectedApp)!

  // Request browser notification permission (so app can push its own alerts)
  const requestNotifPermission = useCallback(async () => {
    if (!("Notification" in window)) return
    const result = await Notification.requestPermission()
    setNotifPermission(result)
    if (result === "granted") {
      new Notification("GALAXIA AI", {
        body: "Notification access granted. GALAXIA can now alert you with tactical suggestions.",
        icon: "/favicon.svg",
      })
    }
  }, [])

  const analyze = useCallback(async () => {
    if (!notifText.trim() || isOverLimit) return
    setLoading(true)
    setError("")
    setSuggestion("")
    try {
      const appLabel = app.label
      const userQuery = `I received a ${appLabel} notification/message:\n\n"${notifText}"${context.trim() ? `\n\nContext: ${context.trim()}` : ""}\n\nGive me the best tactical reply.`
      const result = await askGalaxia({
        mode: "text",
        userText: userQuery,
        conversationHistory: history,
      })
      const reply = result?.trim() || FALLBACK_RESPONSE
      setSuggestion(reply)
      setHistory(prev => [
        ...prev,
        { role: "user", content: notifText },
        { role: "assistant", content: reply },
      ].slice(-16))
    } catch (e: any) {
      setError(friendlyError(e.message ?? ""))
      setSuggestion(FALLBACK_RESPONSE)
    } finally {
      setLoading(false)
    }
  }, [notifText, context, isOverLimit, app, history])

  const handleCopy = async () => {
    if (!suggestion) return
    await navigator.clipboard.writeText(suggestion).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const accentColor = "#f59e0b"

  return (
    <Box
      position="fixed" inset={0} zIndex="modal"
      display="flex" alignItems="flex-end" justifyContent="center"
      css={{ backdropFilter: "blur(12px)", background: "rgba(0,0,0,0.8)" }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <Box w="full" maxW="680px" mx="auto"
        css={{
          background: "rgba(4,3,20,0.98)",
          border: "1px solid rgba(245,158,11,0.4)",
          borderBottom: "none",
          borderRadius: "1.5rem 1.5rem 0 0",
          boxShadow: "0 -4px 60px rgba(245,158,11,0.2), 0 -1px 0 rgba(245,158,11,0.4)",
          maxHeight: "92vh",
          overflowY: "auto",
        }}
      >
        {/* Header */}
        <Box p="5" css={{ borderBottom: "1px solid rgba(245,158,11,0.18)" }}>
          <HStack justify="space-between">
            <HStack gap="3">
              <Box w="9" h="9" borderRadius="xl" display="flex" alignItems="center" justifyContent="center"
                css={{ background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.45)", boxShadow: "0 0 14px rgba(245,158,11,0.35)" }}>
                <Icon boxSize="4" css={{ color: accentColor }}><LuBell /></Icon>
              </Box>
              <VStack align="flex-start" gap="0">
                <Heading size="sm" color="white">Notification Intelligence</Heading>
                <Text fontSize="xs" color="gray.400">Paste any message — GALAXIA crafts the perfect reply</Text>
              </VStack>
            </HStack>
            <Box as="button" onClick={onClose} w="7" h="7" borderRadius="full"
              display="flex" alignItems="center" justifyContent="center" cursor="pointer"
              css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", "&:hover": { background: "rgba(255,255,255,0.1)" } }}>
              <Icon boxSize="3.5" color="gray.400"><LuX /></Icon>
            </Box>
          </HStack>
        </Box>

        <VStack gap="5" p="5" align="stretch">

          {/* Browser notification permission banner */}
          {notifPermission !== "granted" && (
            <Box p="3.5" borderRadius="xl"
              css={{ background: "rgba(245,158,11,0.07)", border: "1px solid rgba(245,158,11,0.25)" }}>
              <HStack justify="space-between" flexWrap="wrap" gap="2">
                <HStack gap="2">
                  <Icon boxSize="4" css={{ color: accentColor }}>{notifPermission === "denied" ? <LuBellOff /> : <LuBellRing />}</Icon>
                  <VStack align="flex-start" gap="0">
                    <Text fontSize="xs" fontWeight="bold" color="yellow.300">
                      {notifPermission === "denied" ? "Notifications blocked" : "Enable push alerts"}
                    </Text>
                    <Text fontSize="xs" color="gray.400">
                      {notifPermission === "denied"
                        ? "Allow in browser settings for GALAXIA push alerts"
                        : "Allow GALAXIA to push tactical alerts to you"}
                    </Text>
                  </VStack>
                </HStack>
                {notifPermission === "default" && (
                  <Box as="button" onClick={requestNotifPermission}
                    px="3" py="1.5" borderRadius="lg" cursor="pointer"
                    css={{ background: "rgba(245,158,11,0.2)", border: "1px solid rgba(245,158,11,0.4)", color: "#fbbf24", fontSize: "12px", fontWeight: "700", "&:hover": { background: "rgba(245,158,11,0.3)" } }}>
                    ALLOW
                  </Box>
                )}
              </HStack>
            </Box>
          )}

          {notifPermission === "granted" && (
            <HStack gap="2" p="2.5" borderRadius="lg"
              css={{ background: "rgba(34,197,94,0.06)", border: "1px solid rgba(34,197,94,0.2)" }}>
              <Icon boxSize="3.5" css={{ color: "#4ade80" }}><LuShieldCheck /></Icon>
              <Text fontSize="xs" color="green.300">Push alerts enabled — GALAXIA can notify you with tactical suggestions</Text>
            </HStack>
          )}

          {/* App source selector */}
          <Box>
            <Text fontSize="xs" color="gray.400" letterSpacing="wider" textTransform="uppercase" mb="2">
              Source App
            </Text>
            <HStack gap="2" flexWrap="wrap">
              {APP_SOURCES.map(a => (
                <Box key={a.id} as="button" onClick={() => setSelectedApp(a.id)}
                  px="3" py="1.5" borderRadius="full" cursor="pointer" transition="all 0.18s"
                  css={{
                    background: selectedApp === a.id ? `${a.color}22` : "rgba(255,255,255,0.04)",
                    border: `1px solid ${selectedApp === a.id ? a.color + "70" : "rgba(255,255,255,0.1)"}`,
                    color: selectedApp === a.id ? a.color : "#6b7280",
                    fontSize: "12px", fontWeight: "600",
                    boxShadow: selectedApp === a.id ? `0 0 10px ${a.color}30` : "none",
                  }}>
                  {a.label}
                </Box>
              ))}
            </HStack>
          </Box>

          {/* Notification text input */}
          <Box>
            <HStack justify="space-between" mb="1.5">
              <Text fontSize="xs" color="gray.400" letterSpacing="wider" textTransform="uppercase">
                Paste the message / notification
              </Text>
              <Text fontSize="xs" fontWeight="semibold"
                css={{ color: isOverLimit ? "#ef4444" : charsLeft <= 200 ? "#f59e0b" : "#4b5563" }}>
                {notifText.length} / {MAX_CHARS}
              </Text>
            </HStack>
            <Box as="textarea"
              value={notifText}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => {
                const v = e.target.value
                setNotifText(v.length > MAX_CHARS ? v.slice(0, MAX_CHARS) : v)
              }}
              placeholder={`Paste the ${app.label} message or notification text here...`}
              rows={4} w="full" p="3"
              onKeyDown={(e: React.KeyboardEvent) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) analyze() }}
              css={{
                background: isOverLimit ? "rgba(239,68,68,0.06)" : "rgba(255,255,255,0.04)",
                border: `1px solid ${isOverLimit ? "rgba(239,68,68,0.5)" : "rgba(245,158,11,0.25)"}`,
                borderRadius: "0.75rem",
                color: "white", fontSize: "0.875rem", lineHeight: "1.6",
                resize: "vertical", outline: "none", fontFamily: "inherit",
                "&::placeholder": { color: "rgba(156,163,175,0.4)" },
                "&:focus": {
                  border: `1px solid ${isOverLimit ? "rgba(239,68,68,0.6)" : "rgba(245,158,11,0.5)"}`,
                  boxShadow: `0 0 0 3px ${isOverLimit ? "rgba(239,68,68,0.1)" : "rgba(245,158,11,0.1)"}`,
                },
              }}
            />
          </Box>

          {/* Optional context */}
          <Box>
            <Text fontSize="xs" color="gray.500" letterSpacing="wider" textTransform="uppercase" mb="1.5">
              Context <Box as="span" textTransform="none" color="gray.600">(optional — relationship, goal, tone)</Box>
            </Text>
            <Box as="input"
              type="text"
              value={context}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setContext(e.target.value)}
              placeholder="e.g. 'Ex I want back', 'Boss I need a raise from', 'First date'"
              maxLength={200}
              w="full" px="3" py="2.5"
              css={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(245,158,11,0.15)",
                borderRadius: "0.75rem",
                color: "white", fontSize: "0.875rem", outline: "none", fontFamily: "inherit",
                "&::placeholder": { color: "rgba(156,163,175,0.35)" },
                "&:focus": { border: "1px solid rgba(245,158,11,0.4)", boxShadow: "0 0 0 3px rgba(245,158,11,0.08)" },
              }}
            />
          </Box>

          {/* Analyze button */}
          <Box as="button" onClick={analyze}
            disabled={loading || !notifText.trim() || isOverLimit}
            w="full" py="3" borderRadius="xl"
            display="flex" alignItems="center" justifyContent="center" gap="2"
            transition="all 0.25s"
            css={{
              background: loading || !notifText.trim() || isOverLimit
                ? "rgba(245,158,11,0.1)"
                : "linear-gradient(135deg, #d97706, #f59e0b)",
              border: "1px solid rgba(245,158,11,0.5)",
              color: loading || !notifText.trim() || isOverLimit ? "rgba(251,191,36,0.4)" : "white",
              fontWeight: "800", fontSize: "0.875rem", letterSpacing: "0.05em",
              boxShadow: loading || !notifText.trim() || isOverLimit ? "none" : "0 0 20px rgba(245,158,11,0.4)",
              cursor: loading || !notifText.trim() || isOverLimit ? "not-allowed" : "pointer",
              "&:hover:not(:disabled)": { boxShadow: "0 0 30px rgba(245,158,11,0.7)", transform: "translateY(-1px)" },
            }}>
            {loading ? (
              <><Box w="4" h="4" borderRadius="full"
                css={{ border: "2px solid rgba(251,191,36,0.3)", borderTop: "2px solid #f59e0b", animation: "spin 0.8s linear infinite" }} />
                GALAXIA AI is analyzing...</>
            ) : (
              <><Icon boxSize="4"><LuSend /></Icon>GENERATE PERFECT REPLY</>
            )}
          </Box>

          {/* Error */}
          {error && (
            <Box p="3" borderRadius="xl"
              css={{ background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.3)" }}>
              <HStack gap="2" mb="1.5">
                <Icon boxSize="4" css={{ color: "#f87171" }}><LuTriangleAlert /></Icon>
                <Text fontSize="sm" color="red.300" fontWeight="semibold">{error}</Text>
              </HStack>
              <Box as="button" onClick={() => { setError(""); analyze() }}
                px="3" py="1.5" borderRadius="lg" cursor="pointer"
                display="flex" alignItems="center" gap="1.5"
                css={{ background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.35)", color: "#fca5a5", fontSize: "12px", fontWeight: "700" }}>
                <Icon boxSize="3"><LuRefreshCw /></Icon>TRY AGAIN
              </Box>
            </Box>
          )}

          {/* Suggestion */}
          {suggestion && (
            <Box p="4" borderRadius="xl"
              css={{ background: "rgba(245,158,11,0.07)", border: "1px solid rgba(245,158,11,0.4)", boxShadow: "0 0 20px rgba(245,158,11,0.15)" }}>
              <HStack justify="space-between" mb="3">
                <HStack gap="2">
                  <Box w="2" h="2" borderRadius="full" css={{ background: accentColor, animation: "pulse 2s infinite" }} />
                  <Text fontSize="xs" fontWeight="bold" letterSpacing="widest" textTransform="uppercase"
                    css={{ color: accentColor, textShadow: "0 0 8px rgba(245,158,11,0.6)" }}>
                    GALAXIA REPLY
                  </Text>
                </HStack>
                <Box as="button" onClick={() => { setSuggestion(""); analyze() }}
                  display="flex" alignItems="center" gap="1.5" px="2.5" py="1" borderRadius="lg" cursor="pointer"
                  css={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#9ca3af", fontSize: "11px", fontWeight: "600", "&:hover": { background: "rgba(255,255,255,0.1)" } }}>
                  <Icon boxSize="3"><LuRefreshCw /></Icon>REGENERATE
                </Box>
              </HStack>
              <Text fontSize="md" color="white" lineHeight="tall" mb="4">{suggestion}</Text>
              <Box as="button" onClick={handleCopy} w="full" py="2.5" borderRadius="lg"
                display="flex" alignItems="center" justifyContent="center" gap="2"
                transition="all 0.2s" cursor="pointer"
                css={{
                  background: copied ? "rgba(245,158,11,0.3)" : "rgba(245,158,11,0.12)",
                  border: `1px solid ${copied ? "#f59e0b" : "rgba(245,158,11,0.4)"}`,
                  color: copied ? "#fbbf24" : accentColor,
                  fontWeight: "700", fontSize: "0.8rem", letterSpacing: "0.08em",
                  "&:hover": { background: "rgba(245,158,11,0.25)" },
                }}>
                <Icon boxSize="4">{copied ? <LuCheck /> : <LuCopy />}</Icon>
                {copied ? "COPIED!" : "COPY REPLY"}
              </Box>
            </Box>
          )}
        </VStack>
      </Box>
    </Box>
  )
}
