'use client'

import { Box, HStack, StackSeparator, defineStyle } from '@chakra-ui/react'
import { EditorContent } from '@tiptap/react'
import {
  RichTextEditorContext,
  useRichTextEditorContext,
} from './rich-text-editor-context'
import * as React from 'react'

const proseMirrorBaseCss = defineStyle({
  display: 'flex',
  flexDirection: 'column',
  borderWidth: '1px',
  rounded: 'l2',
  lineHeight: '1.5',

  '--content-padding-x': 'spacing.5',
  '--content-padding-y': 'spacing.5',

  '& img.ProseMirror-selectednode': {
    outlineWidth: '2px',
    outlineStyle: 'solid',
    outlineColor: 'blue.focusRing',
  },

  '& .ProseMirror': {
    outline: 'none',
    minHeight: 'var(--content-min-height)',
    px: 'var(--content-padding-x)',
    py: 'var(--content-padding-y)',
    '& > * + *': { marginTop: '0.75em' },
    '& h1': {
      fontSize: '2.15em',
      letterSpacing: '-0.02em',
      lineHeight: '1.2em',
    },
    '& h2': {
      fontSize: '1.65em',
      letterSpacing: '-0.02em',
      lineHeight: '1.3em',
    },
    '& h3': {
      fontSize: '1.35em',
      letterSpacing: '-0.01em',
      lineHeight: '1.4em',
    },
    '& h4': {
      fontSize: '1.15em',
      letterSpacing: '-0.01em',
      lineHeight: '1.5em',
    },
    '& h5': {
      fontSize: '1em',
      letterSpacing: '-0.01em',
      lineHeight: '1.5em',
    },
    '& h6': {
      fontSize: '0.875em',
      letterSpacing: '-0.01em',
      lineHeight: '1.5em',
    },
    '& h1, h2, h3, h4, h5, h6': {
      color: 'fg',
      fontWeight: '600',
    },
    '& code': {
      bg: 'bg.muted',
      paddingInline: '0.25em',
      rounded: 'sm',
      fontFamily: 'mono',
      fontSize: '0.9em',
      borderWidth: '1px',
    },
    '& pre': {
      bg: 'gray.900',
      color: 'gray.100',
      padding: '4',
      rounded: 'lg',
      overflowX: 'auto',
      fontSize: 'sm',
      lineHeight: '1.6',
      borderWidth: '1px',
      borderColor: 'gray.700',
      boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.03)',
    },
    '& pre code': {
      bg: 'transparent',
      padding: '0',
      fontFamily: 'mono',
      color: 'inherit',
      borderWidth: '0',
    },
    '& blockquote': {
      borderStartWidth: '4px',
      borderStartColor: 'border',
      paddingStart: '4',
    },
    "& ul:not([data-type='taskList'])": {
      paddingInlineStart: '1.25rem',
      listStyleType: 'disc',
    },
    "& ol:not([data-type='taskList'])": {
      paddingInlineStart: '1.25rem',
      listStyleType: 'decimal',
    },
    '& ul ul': {
      listStyleType: 'circle',
    },
    '& ul ul ul': {
      listStyleType: 'square',
    },
    "& ul[data-type='taskList'] li": {
      listStyle: 'none',
      display: 'flex',
      alignItems: 'flex-start',
      gap: '2',
      "& input[type='checkbox']": {
        accentColor: 'colorPalette.solid',
        marginTop: '1',
      },
    },
    '& hr': { my: '4' },
    '& a': { color: 'blue.fg', textDecoration: 'underline' },
    '& em': { fontStyle: 'italic' },
    '& strong': { fontWeight: 'bold' },
    '& p.is-editor-empty:first-of-type::before': {
      content: 'attr(data-placeholder)',
      color: 'fg.muted',
      pointerEvents: 'none',
      float: 'left',
      height: '0',
    },

    '& .node-hashtag': {
      layerStyle: 'fill.surface',
      px: '0.25em',
      py: '2px',
      rounded: 'l1',
    },
  },

  '&[data-disabled] .ProseMirror': {
    pointerEvents: 'none',
    opacity: 0.5,
    cursor: 'not-allowed',
  },
})

export const RichTextEditorRoot = React.forwardRef(
  function RichTextEditorRoot(props, ref) {
    const { editor, children, css, disabled, ...rest } = props
    const contextValue = React.useMemo(() => ({ editor }), [editor])
    return (
      <RichTextEditorContext.Provider value={contextValue}>
        <Box
          ref={ref}
          data-disabled={disabled || undefined}
          css={[proseMirrorBaseCss, css]}
          {...rest}
        >
          {children}
        </Box>
      </RichTextEditorContext.Provider>
    )
  },
)

const toolbarStylesMap = {
  sticky: {
    bg: 'bg',
    position: 'sticky',
    top: 'var(--sticky-offset, 0px)',
    zIndex: '1',
    py: '1.5',
    px: '3',
  },
  fixed: {
    bg: 'bg',
    roundedTop: 'l2',
    borderBottomWidth: '1px',
    py: '1.5',
    px: '3',
  },
  floating: {
    shadow: 'md',
    roundedTop: 'l2',
    bg: 'bg.panel',
    px: '1.5',
    py: '1.5',
  },
}

export const RichTextEditorToolbar = React.forwardRef(
  function RichTextEditorToolbar(props, ref) {
    const { variant = 'fixed', stickyOffset = '0px', ...rest } = props
    const variantStyles = toolbarStylesMap[variant]

    return (
      <HStack
        ref={ref}
        flexWrap='wrap'
        separator={<StackSeparator h='5' alignSelf='center' />}
        {...rest}
        style={{
          ['--sticky-offset']: stickyOffset,
          ...rest.style,
        }}
        css={[variantStyles, rest.css]}
      />
    )
  },
)

export const RichTextEditorFooter = React.forwardRef(
  function RichTextEditorFooter(props, ref) {
    return <HStack ref={ref} gap='1' borderTopWidth='1px' p='3' {...props} />
  },
)

export const RichTextEditorContent = React.forwardRef(
  function RichTextEditorContent(props, ref) {
    const { editor } = useRichTextEditorContext()
    if (!editor) return null
    return <EditorContent editor={editor} {...props} innerRef={ref} />
  },
)

export const RichTextEditorControlGroup = React.forwardRef(
  function RichTextEditorButtonGroup(props, ref) {
    return <HStack ref={ref} gap='1' {...props} />
  },
)

export const RichTextEditor = {
  Root: RichTextEditorRoot,
  Toolbar: RichTextEditorToolbar,
  Content: RichTextEditorContent,
  ControlGroup: RichTextEditorControlGroup,
  Footer: RichTextEditorFooter,
}

export * as Control from './rich-text-editor-control'

export {
  createBooleanControl,
  createSelectControl,
  createSwatchControl,
} from 'compositions/ui/rich-text-editor-control'

export { useRichTextEditorContext } from 'compositions/ui/rich-text-editor-context'
