-- Anonymized session memory: stores only abstract patterns, NOT personal data
CREATE TABLE session_memory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,              -- client-generated anonymous ID
  mode text NOT NULL,                    -- text | phone | video | facetoface
  pattern_summary text NOT NULL,         -- AI-extracted abstract pattern (no PII)
  vocabulary_tags text[] DEFAULT '{}',   -- extracted style/vocab tags
  strategy_tags text[] DEFAULT '{}',     -- negotiation strategies observed
  created_at timestamptz DEFAULT now()
);

-- Daily usage tracking keyed by anonymous session ID
CREATE TABLE usage_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  usage_date date NOT NULL DEFAULT CURRENT_DATE,
  message_count integer NOT NULL DEFAULT 0,
  minutes_used numeric(6,2) NOT NULL DEFAULT 0,
  time_saved_seconds integer NOT NULL DEFAULT 0,
  UNIQUE(session_id, usage_date)
);

-- Indexes for fast lookup
CREATE INDEX idx_session_memory_session ON session_memory(session_id);
CREATE INDEX idx_session_memory_mode ON session_memory(mode);
CREATE INDEX idx_usage_stats_session_date ON usage_stats(session_id, usage_date);

-- RLS
ALTER TABLE session_memory ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_stats ENABLE ROW LEVEL SECURITY;

-- Allow anyone (anonymous client) to insert/select their own session data
CREATE POLICY "insert_session_memory" ON session_memory FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "select_session_memory" ON session_memory FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "delete_session_memory" ON session_memory FOR DELETE TO anon, authenticated USING (true);
CREATE POLICY "update_session_memory" ON session_memory FOR UPDATE TO anon, authenticated USING (true);

CREATE POLICY "insert_usage_stats" ON usage_stats FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "select_usage_stats" ON usage_stats FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "update_usage_stats" ON usage_stats FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_usage_stats" ON usage_stats FOR DELETE TO anon, authenticated USING (true);
